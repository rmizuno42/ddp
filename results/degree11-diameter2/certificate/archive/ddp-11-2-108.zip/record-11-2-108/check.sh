#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
tmp=$(mktemp -d .verify.XXXXXXXX)
trap 'rm -rf "$tmp"' EXIT
python3 construct.py "$tmp/regenerated.edges"
cmp graph108.edges "$tmp/regenerated.edges"
python3 verify_layers.py graph108.edges "$tmp/layers.bin"
c++ -std=c++17 -O2 verify_queue.cpp -o "$tmp/verify_queue"
"$tmp/verify_queue" graph108.edges "$tmp/queue.bin"
cmp "$tmp/layers.bin" "$tmp/queue.bin"
sha256sum graph108.edges
(cd "$tmp" && sha256sum queue.bin)
