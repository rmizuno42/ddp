from itertools import combinations
from pathlib import Path
from collections import Counter
import json

def distant_components(adj):
    groups=[{i} for i in range(len(adj))]
    for i,j in combinations(range(len(adj)),2):
        if not adj[i]&(1<<j|adj[j]):
            a=next(g for g in groups if i in g);b=next(g for g in groups if j in g)
            if a!=b:a.update(b);groups.remove(b)
    return sorted(groups,key=lambda g:(-len(g),min(g)))
def partitions(prefix,pending):
    if not pending:
        if len(prefix)<=13:yield prefix
        return
    x=pending[0]
    for i,g in enumerate(prefix):
        if len(g)+len(x)<=3:yield from partitions(prefix[:i]+[g|x]+prefix[i+1:],pending[1:])
    if len(prefix)<13:yield from partitions(prefix+[x],pending[1:])
def feasible(adj,groups):
    h=len(groups);labels={p:i for i,g in enumerate(groups) for p in g}
    common=[]
    for i,g in enumerate(groups):
        neigh=[{labels[q] for q in range(len(adj)) if adj[p]>>q&1}-{i} for p in g]
        common.append(set.intersection(*neigh))
    M=[[0]*13 for _ in range(13)]
    for i,j in combinations(range(13),2):
        if i>=h:continue
        if j>=h or j not in common[i] or i not in common[j]:M[i][j]=M[j][i]=1
    return M if all(sum(row)+(len(groups[i]) if i<h else 0)<=11 for i,row in enumerate(M)) else None
def main(source,destination):
    results=[];stats=[]
    for idx,line in enumerate(Path(source).read_text().splitlines()):
        a=list(map(int,line.split()));blocks=distant_components(a)
        count=Counter()
        for g in partitions([],blocks):
            count['checked']+=1
            M=feasible(a,g)
            if M is None:continue
            count['kept']+=1;results.append([idx,[sorted(x) for x in g],M])
        print(idx,dict(count))
        stats.append(count)
    Path(destination).write_text(json.dumps(results,separators=(',',':')))
if __name__=='__main__':main('fixed17-candidates.txt','fixed17-partitions.json')
