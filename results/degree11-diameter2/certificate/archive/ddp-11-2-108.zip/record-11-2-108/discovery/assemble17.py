from collections import Counter, defaultdict
from itertools import combinations,permutations
from pathlib import Path
cores=Path('anchor17-singletons.txt').read_text().splitlines()
def edges_of(i):
    return [e for e,v in zip(combinations(range(7),2),cores[i]) if v=='1']
def orth(a,b):
    return len({(x-y)%7 for x,y in zip(a,b)})==7
records=[]
for line in Path('outer17-patterns.txt').read_text().splitlines():
    c,l,S,t,p=line.split();c=int(c);t=list(map(int,t));p=list(map(int,p));edges=edges_of(c)
    h={0:0}
    while len(h)<7:
        for (i,j),x in zip(edges,p):
            if i in h and j not in h:h[j]=(h[i]+x)%7
            elif j in h and i not in h:h[i]=(h[j]-x)%7
    key=tuple((x+h[i]-h[j])%7 for (i,j),x in zip(edges,p))
    g=tuple(h[i] for i in range(7));g2=tuple((h[i]+t[i]-t[0])%7 for i in range(7))
    records.append((key,g,g2))
counts=Counter()
for (key,g,b),(key2,g2,b2) in combinations(records,2):
    if key==key2 and all(orth(x,y) for x in (g,b) for y in (g2,b2)):counts['two']+=1
print('pair_records',len(records),'keys',len({k for k,_,_ in records}),'compatible_pairs',counts['two'])
# Relative to a fixed parallel pair, all columns of another component are permutations at
# the seven centers, and are orthogonal to the second column of the pair.
for j,line in enumerate(Path('outer17-patterns.txt').read_text().splitlines()):
    c,l,S,t,p=line.split();t=list(map(int,t));p=list(map(int,p));E=edges_of(int(c))
    choices=[]
    for h0 in permutations(range(1,7)):
        h=(0,)+h0
        if not orth(h,t):continue
        holes=[]
        for i in range(7):
            seen={h[i]}
            for (a,b),x in zip(E,p):
                if a==i:seen.add((x+h[b])%7)
                if b==i:seen.add((-x+h[a])%7)
            holes.append(tuple(sorted(set(range(7))-seen)))
        if all(len(H)<=4 for H in holes):choices.append((h,holes))
    print('pair',j,'raw_compatible',sum(orth((0,)+q,t) for q in permutations(range(1,7))),'coverable_columns',len(choices))
