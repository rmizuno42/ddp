from itertools import combinations,product
from collections import Counter
from pathlib import Path
import json
from audit import list_search,bit_search
from assemble17 import edges_of,orth
models=Path('outer17-patterns.txt').read_text().splitlines();cols=[];source=[]
for line in models:
    core,loops,S,t,p=line.split();t,p=list(map(int,t)),list(map(int,p));E=edges_of(int(core));h={0:0}
    while len(h)<7:
        for (i,j),x in zip(E,p):
            if i in h and j not in h:h[j]=(h[i]+x)%7
            elif j in h and i not in h:h[i]=(h[j]-x)%7
    key=tuple((x+h[i]-h[j])%7 for (i,j),x in zip(E,p));source.append((key,int(S)))
    cols.append([tuple(h[i] for i in range(7)),tuple((h[i]+t[i])%7 for i in range(7))])
def build(picked):
    F=list(map(int,Path('fixed17-candidates.txt').read_text().splitlines()[0].split()))
    _,groups,W=json.loads(Path('fixed17-partitions.json').read_text())[0]
    E={(i,j) for i,j in combinations(range(17),2) if F[i]>>j&1}
    def link(i,j):E.add(tuple(sorted((i,j))))
    def v(i,x):return 17+7*i+x%7
    for x in range(7):
        for i,g in enumerate(groups):
            for a in g:link(a,v(i,x))
        for (i,j),b in zip(edges_of(0),source[picked[0]][0]):link(v(i,x),v(j,x+b))
        for j,choice in enumerate(picked):
            u=7+2*j;w=u+1
            for s in range(7):
                if source[choice][1]>>s&1:link(v(w,x),v(u,x+s))
            for k,c in enumerate(cols[choice]):
                for i,a in enumerate(c):link(v(i,x),v(u+k,x+a))
    return E
hist=Counter()
best=None;outfile=Path('pair-components108.edges')
for picked in combinations(range(len(models)),3):
    if len({source[j][0] for j in picked})!=1:continue
    if not all(orth(a,b) for j,k in combinations(picked,2) for a in cols[j] for b in cols[k]):continue
    E=build(picked);A=[set() for _ in range(108)]
    for u,v in E:A[u].add(v);A[v].add(u)
    far=sum(v not in A[u] and A[u].isdisjoint(A[v]) for u,v in combinations(range(108),2))
    hist[far]+=1
    if best is None or far<best:
        best=far
        outfile.write_text(''.join(f'{u} {v}\n' for u,v in sorted(E)))
        a=list_search(outfile,108,2);assert a==bit_search(outfile,108,2) and a[0]<=11 and a[2]==far
        print('best',picked,a,len(E))
        if far==0:break
print('three_components',sorted(hist.items()))
