"""Check saved witnesses using independent edge parsers and BFS implementations."""
from collections import deque
from pathlib import Path


def list_search(path, n, D):
    adj = [set() for _ in range(n)]
    for line in path.read_text().splitlines():
        u, v = map(int, line.split())
        assert 0 <= u < n and 0 <= v < n and u != v and v not in adj[u]
        adj[u].add(v)
        adj[v].add(u)
    far = unreachable = diameter = 0
    for source in range(n):
        dist = [-1] * n
        dist[source] = 0
        q = deque([source])
        while q:
            u = q.popleft()
            for v in adj[u]:
                if dist[v] == -1:
                    dist[v] = dist[u] + 1
                    q.append(v)
        unreachable += dist.count(-1)
        far += sum(d == -1 or d > D for d in dist)
        diameter = max(diameter, max(dist))
    return max(map(len, adj)), unreachable // 2, far // 2, diameter


def bit_search(path, n, D):
    nb = [0] * n
    for raw in path.open('rb'):
        a, b = (int(x) for x in raw.split())
        assert a != b and not (nb[a] >> b & 1)
        nb[b] |= 1 << a
        nb[a] |= 1 << b
    unreachable = far = diameter = 0
    for i in range(n):
        layer = seen = 1 << i
        depth = 0
        while layer:
            following = 0
            while layer:
                low = layer & -layer
                layer -= low
                following |= nb[low.bit_length() - 1]
            layer = following & ~seen
            if depth == D:
                far += n - seen.bit_count()
            if layer:
                depth += 1
            seen |= layer
        missing = n - seen.bit_count()
        unreachable += missing
        if depth < D:
            far += missing
        diameter = max(diameter, depth)
    return max(x.bit_count() for x in nb), unreachable // 2, far // 2, diameter



