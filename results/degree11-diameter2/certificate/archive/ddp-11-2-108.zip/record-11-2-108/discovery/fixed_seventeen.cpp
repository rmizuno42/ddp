#include <algorithm>
#include <array>
#include <cassert>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
using namespace std;
using Graph=array<int,12>;
int pop(int a){return __builtin_popcount((unsigned)a);}
string canonical(const Graph& g,vector<int> cells){
    for(;;){
        vector<int> next;
        for(int mask:cells){
            map<unsigned long long,int> bins;
            for(int m=mask;m;m&=m-1){
                int v=__builtin_ctz((unsigned)m);unsigned long long key=0;
                for(int c:cells)key=16*key+pop(g[v]&c);
                bins[key]|=1<<v;
            }
            for(auto [k,b]:bins)next.push_back(b);
        }
        if(next.size()==cells.size())break;
        cells=move(next);
    }
    for(int i=0;i<(int)cells.size();++i)if(pop(cells[i])>1){
        string best;
        for(int m=cells[i];m;m&=m-1){
            int b=m&-m;auto child=cells;child[i]^=b;child.insert(child.begin()+i,b);
            string s=canonical(g,child);if(best.empty()||s<best)best=move(s);
        }
        return best;
    }
    string s;for(int i=0;i<12;++i)for(int j=0;j<i;++j)
        s+=char('0'+bool(g[__builtin_ctz((unsigned)cells[i])]&cells[j]));
    return s;
}
vector<Graph> cubic;
set<string> codes;
long long labelings=0,small=0;
int histogram[18]={};
ofstream output("fixed17-candidates.txt");
void match(Graph& g,int remain){
    if(!remain){
        ++labelings;
        if(codes.insert(canonical(g,{4095})).second)cubic.push_back(g);
        return;
    }
    int u=__builtin_ctz((unsigned)remain);remain^=1<<u;
    for(int m=remain&~g[u];m;m&=m-1){
        int b=m&-m,v=__builtin_ctz((unsigned)b);
        g[u]|=b;g[v]|=1<<u;match(g,remain^b);g[u]^=b;g[v]^=1<<u;
    }
}
void cycles(Graph g,int start,int lo){
    if(start==12){match(g,4095);return;}
    for(int n=lo;start+n<=12;++n){
        auto h=g;for(int j=0;j<n;++j){
            int u=start+j,v=start+(j+1)%n;h[u]|=1<<v;h[v]|=1<<u;
        }
        cycles(h,start+n,n);
    }
}
void test(const Graph& r,const array<int,4>& groups){
    array<int,17> adj{};adj[0]=30;
    for(int i=0;i<4;++i)adj[i+1]=1|(groups[i]<<5);
    for(int j=0;j<12;++j){
        adj[5+j]=r[j]<<5;
        for(int i=0;i<4;++i)if(groups[i]>>j&1)adj[5+j]|=1<<(1+i);
    }
    int components[17]={},maxSize=1;
    for(int i=0;i<17;++i){
        int reach=(1<<i)|adj[i];
        for(int m=adj[i];m;m&=m-1)reach|=adj[__builtin_ctz((unsigned)m)];
        components[i]=131071^reach;
    }
    int remaining=131071;
    while(remaining){
        int c=remaining&-remaining,next=c;
        while(next){
            int v=__builtin_ctz((unsigned)next);next&=next-1;
            next|=components[v]&~c;c|=components[v];
        }
        remaining&=~c;maxSize=max(maxSize,pop(c));
        if(maxSize>3)break;
    }
    ++histogram[maxSize];
    if(maxSize>3)return;
    ++small;
    for(int m:adj)output<<m<<' ';output<<'\n';
}
vector<array<int,4>> partitions;
void triples(int remain,int pos,array<int,4> groups){
    if(!remain){partitions.push_back(groups);return;}
    int a=remain&-remain,m=remain^a;
    for(int p=m;p;p&=p-1){
        int b=p&-p;
        for(int q=p^b;q;q&=q-1){
            int c=q&-q;groups[pos]=a|b|c;triples(remain^groups[pos],pos+1,groups);
        }
    }
}
int main(){
    cycles({},0,3);triples(4095,0,{});
    cout<<"cubic_representations "<<labelings<<" types "<<cubic.size()<<" partitions "<<partitions.size()<<endl;
    assert(partitions.size()==15400);
    for(auto& g:cubic)for(auto& P:partitions)test(g,P);
    cout<<"far_components_at_most_three "<<small<<endl;
}
