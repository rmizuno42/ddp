#include <algorithm>
#include <array>
#include <cassert>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
int mod(int x){return (x+21)%7;}
int pop(int x){return __builtin_popcount((unsigned)x);}
int rotate(int b,int s){return ((b<<s)|(b>>(7-s)))&127;}
struct Model{
    int core,loops,S,U,required,M[7][7]={},deg[7]={},ways[7][7]={};
    int t[7],need[7],rem[7],used[7][2]={},voltage[12]={};
    int occupied=0;vector<pair<int,int>> edges;
    long long potentials=0,nodes=0,valid=0;
    Model(int id,string w,int l,int s):core(id),loops(l),S(s),U(1|l){
        int k=0;
        for(int i=0;i<7;++i)for(int j=i+1;j<7;++j)if(w[k++]=='1'){
            edges.push_back({i,j});M[i][j]=M[j][i]=1;++deg[i];++deg[j];
        }
        for(int i=0;i<7;++i)for(int j=0;j<i;++j){
            ways[i][j]=M[i][j];for(int v=0;v<7;++v)ways[i][j]+=M[i][v]*M[v][j];
        }
        int reached=S;for(int a=1;a<7;++a)if(l>>a&1)reached|=rotate(S,a);
        required=127^reached;
    }
    bool fits(int i,int p,int q){
        return pop(need[i]&~(used[i][0]|(1<<p)))<rem[i]&&pop(need[i]&~(used[i][1]|(1<<q)))<rem[i];
    }
    void edgesearch(int depth,ostream& out){
        ++nodes;
        if(depth==(int)edges.size()){
            ++valid;
            out<<core<<' '<<loops<<' '<<S<<' ';
            for(int v:t)out<<v;out<<' ';for(size_t e=0;e<edges.size();++e)out<<voltage[e];out<<'\n';return;
        }
        int best=-1,options=0;
        for(int e=0;e<(int)edges.size();++e)if(!(occupied>>e&1)){
            auto [i,j]=edges[e];int mask=0;
            for(int p=0;p<7;++p){
                int q=mod(t[i]-t[j]-p);
                if(fits(i,p,q)&&fits(j,mod(-p),mod(-q)))mask|=1<<p;
            }
            if(!mask)return;
            if(best<0||pop(mask)<pop(options)){best=e;options=mask;}
        }
        auto [i,j]=edges[best];int save[]={used[i][0],used[i][1],used[j][0],used[j][1]};
        --rem[i];--rem[j];occupied^=1<<best;
        for(;options;options&=options-1){
            int p=__builtin_ctz((unsigned)options),q=mod(t[i]-t[j]-p);
            voltage[best]=p;
            used[i][0]=save[0]|(1<<p);used[i][1]=save[1]|(1<<q);
            used[j][0]=save[2]|(1<<mod(-p));used[j][1]=save[3]|(1<<mod(-q));
            edgesearch(depth+1,out);
        }
        ++rem[i];++rem[j];occupied^=1<<best;
        used[i][0]=save[0];used[i][1]=save[1];used[j][0]=save[2];used[j][1]=save[3];
    }
    void assign(int i,int colors,ostream& out){
        if(i<7){
            for(t[i]=0;t[i]<7;++t[i]){
                need[i]=127^(U|rotate(S,t[i]));
                if(pop(need[i])>deg[i])continue;
                bool ok=true;for(int j=0;j<i;++j)if(t[i]==t[j]&&ways[i][j]<2)ok=false;
                if(ok)assign(i+1,colors|(1<<mod(-t[i])),out);
            }
            return;
        }
        if(required&~colors)return;
        for(int i=0;i<7;++i)if(pop(need[i])==deg[i]){
            int v=deg[i]*t[i];for(int j=0;j<7;++j){if(M[i][j])v-=t[j];if(need[i]>>j&1)v-=2*j;}
            if(v%7)return;
        }
        ++potentials;
        for(int j=0;j<7;++j){rem[j]=deg[j];used[j][0]=used[j][1]=0;}
        edgesearch(0,out);
    }
};
int main(){
    ifstream in("anchor17-singletons.txt");ofstream out("outer17-patterns.txt");string w;int id=0;
    while(in>>w){
        for(int mask=0;mask<128;++mask)if(pop(mask)==4){
            int m=mask;for(int a=1;a<7;++a)m=min(m,rotate(mask,a));
            if(m!=mask)continue;
            Model q(id,w,0,mask);q.assign(0,0,out);
            cout<<id<<" parallel "<<mask<<' '<<q.potentials<<' '<<q.nodes<<' '<<q.valid<<endl;
        }
        for(int a=1;a<=3;++a){
            int b=mod(2*a);int l=(1<<a)|(1<<(7-a)),s=(1<<b)|(1<<(7-b));
            Model q(id,w,l,s);q.assign(0,0,out);
            cout<<id<<" loops "<<a<<' '<<q.potentials<<' '<<q.nodes<<' '<<q.valid<<endl;
        }
        ++id;
    }
}
