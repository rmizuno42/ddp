#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
c++ -std=c++17 -O3 fixed_seventeen.cpp -o fixed17.run
./fixed17.run
python3 anchor_partition.py
python3 - <<'PY'
from pathlib import Path
import json
from itertools import combinations
rows=json.loads(Path('fixed17-partitions.json').read_text())
Path('anchor17-singletons.txt').write_text(''.join(''.join(str(W[i][j]) for i,j in combinations(range(7),2))+'\n' for _,g,W in (rows[0],rows[2])))
PY
c++ -std=c++17 -O3 outer_pairs17.cpp -o outer17.run
./outer17.run
python3 assemble17_bfs.py
cmp pair-components108.edges ../graph108.edges
