# 新しい下界 N(3,7) ≥ 208

**208頂点、312辺、3正則、直径7、girth 9。全自己同型群は C16。**
この対話で以前に構成した204頂点を4頂点上回る。
今回取得できた指定表の (3,7) の掲載値196との比較では12頂点増。
最適性、文献全体での先取権、記録表への採録は主張しない。

`proof_ja.md` に短い明示構成、直径の証明、girthと自己同型群の証明を記載している。
既存の小さい下界に頂点を付け足したものではない。探索は最初から208頂点を固定し、既存グラフを入力に使わない。

## 検証

Python 3.10以降の標準ライブラリだけで、ネットワーク接続なしに動く。

```sh
python3 run_all.py
```

最終行:

```text
VERIFIED: N(3,7) >= 208; a simple cubic graph with diameter 7 and girth 9.
```

一括検証は、ハッシュ、構成と各ファイルの一致、全21,528頂点対の距離、全169個の剰余類到達集合、
13本の深さ7の全域木証明書、発見時のグラフとの同型、girth 9、Aut(G)=C16を検査する。

不成功例もすべて再検査するには:

```sh
python3 run_all.py --all-candidates
```

辺ファイル単独の検査:

```sh
python3 verify.py graphs/n37_208.edges --degree 3 --diameter 7
```

新規ディレクトリへ明示式からグラフを書き出すには:

```sh
python3 construct.py --out reconstructed
```

任意の発見再現（こちらのみg++が必要）:

```sh
python3 discovery/replay.py
```

## ファイル

`graphs/n37_208.edges` は、1行目が頂点数、残りが一辺ずつの整数対。
`graphs/n37_208.adjlist` は、各行が頂点番号と**すべての**隣接頂点を並べた完全な隣接リスト。
整数ラベルは `(i,x) ↦ 16i+x`。

`certificates/` は直径の上界の全域木証明書、`reports/` は実際の検査結果。
`discovery/` は探索ソース、乱数種・反復回数、成功ログ、元の電圧表、正規化の対応。
`additional_searches/` はこの成功後も続けた探索を含む全31回の探索実行と7件の縮約検査。
有効な新下界は208頂点の例だけであり、ほかのファイルを記録更新として扱ってはならない。

追加のNetworkX検算結果も保存したが、上記の主要検証にはNetworkXは不要。
SHA256SUMSは配布ファイルの固定ハッシュ一覧で、Pythonのキャッシュ等の実行時生成物は対象外。

参考: 指定表
https://web.mat.upc.edu/francesc.comellas/delta-d/table_degree_diameter.html
