#!/usr/bin/env python3
"""Enumerate quotient-perfect-matchings and contract their lifts, no vertex addition."""
from pathlib import Path
import json,sys,time

def run(src):
 rows=[list(map(int,line.split())) for line in src.read_text().splitlines() if line.strip()]
 B,Q,K,D,M=rows[0];E=rows[1:]
 if B%2: return None
 inc=[[] for _ in range(B)]
 for z,(a,b,t,h) in enumerate(E):
  if a!=b:inc[a].append((b,z));inc[b].append((a,z))
 best=10**9;bestE=None;bestMat=None;count=0;newB=B//2;full=(1<<Q)-1
 def evaluate(chosen):
  nonlocal best,bestE,bestMat,count
  count+=1;idx=[0]*B;off=[0]*B
  for i,z in enumerate(chosen):
   a,b,t,h=E[z];idx[a]=idx[b]=i;off[b]=t
  chosen=set(chosen);NE=[];seen=set()
  for z,(a,b,t,h) in enumerate(E):
   if z in chosen:continue
   na,nb=idx[a],idx[b];s=(off[a]+t-off[b])%Q
   if na>nb:na,nb,s=nb,na,-s%Q
   if na==nb:s=min(s,-s%Q)
   if na==nb and s==0:return
   edge=(na,nb,s,h)
   if edge in seen:return
   seen.add(edge);NE.append(edge)
  adj=[[] for _ in range(newB)]
  for a,b,t,h in NE:
   adj[a].append((b,t))
   if not h:adj[b].append((a,-t%Q))
  if any(len(x)!=4 for x in adj):return
  total=0
  for root in range(newB):
   v=[0]*newB;v[root]=1
   for _ in range(4):
    w=v[:]
    for a in range(newB):
     for b,t in adj[a]:w[b]|=((v[a]<<t)|(v[a]>>(Q-t)))&full
    v=w
   total+=sum(Q+x.bit_count()*-1 for x in v)
   if total>best:return
  if total<best:best=total;bestE=NE;bestMat=sorted(chosen);print(src.stem,'matching',count,'best',best,'bad pairs',best*Q//2,flush=True)
 def rec(rem,chosen):
  if rem==0:evaluate(chosen);return
  a=min((i for i in range(B) if rem>>i&1),key=lambda i:sum(bool(rem>>b&1) for b,z in inc[i]))
  for b,z in inc[a]:
   if rem>>b&1:rec(rem^(1<<a)^(1<<b),chosen+[z])
 rec((1<<B)-1,[])
 out=src.parent/('contract_'+src.stem)
 res=dict(source=str(src),order=newB*Q,degree=4,diameter_target=4,matchings_checked=count,orbit_defect=best,bad_pairs=best*Q//2,matching_edges=bestMat,valid=best==0)
 out.with_suffix('.json').write_text(json.dumps(res,indent=2)+'\n')
 if bestE:
  out.with_suffix('.voltage').write_text(f'{newB} {Q} 4 4 {len(bestE)}\n'+''.join(' '.join(map(str,e))+'\n' for e in bestE))
  es={tuple(sorted((a*Q+x,b*Q+(x+t)%Q))) for a,b,t,h in bestE for x in range(Q)}
  out.with_suffix('.edges').write_text(f'{newB*Q}\n'+''.join(f'{a} {b}\n' for a,b in sorted(es)))
 print('FINAL',res,flush=True);return res
if __name__=='__main__':
 for name in sys.argv[1:]:run(Path(name))
