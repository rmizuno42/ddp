import subprocess, pathlib, json, sys
root=pathlib.Path(__file__).parent
configs=[(13,16,3,7,100,926001,'c208_b13',30000,9),(15,14,3,7,100,926002,'c210_b15',30000,9),(18,12,3,7,100,926003,'c216_b18',30000,9),(8,26,3,7,100,926004,'c208_b8',30000,9)]
rows=[]
for b,q,k,d,sec,seed,name,period,T in configs:
    args=[str(root/'cyclic_design'),str(b),str(q),str(k),str(d),str(sec),str(seed),str(root/'runs'/name),str(period),str(T)]
    with open(root/'runs'/f'{name}.log','w') as log:
        p=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
    rows.append(dict(name=name,pid=p.pid,args=args))
print(json.dumps(rows,indent=2))
(root/'runs'/'batch1.json').write_text(json.dumps(rows,indent=2))
