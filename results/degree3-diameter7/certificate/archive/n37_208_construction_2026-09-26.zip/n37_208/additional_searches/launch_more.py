import subprocess,pathlib,json,sys
r=pathlib.Path(__file__).parent
# Launch explicit fixed-order experiments, recording full commands.
rows=[]
for arg in sys.argv[1:]:
 p=arg.split(',');exe=p[0];b,q,k,d,sec,seed=p[1:7];name=p[7];tail=p[8:]
 cmd=[str(r/exe),b,q,k,d,sec,seed,str(r/'runs'/name),*tail]
 with open(r/'runs'/f'{name}.log','w') as log:
  child=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
 row=dict(name=name,pid=child.pid,args=cmd);rows.append(row)
 with open(r/'runs'/'commands.jsonl','a') as log:log.write(json.dumps(row)+'\n')
print(json.dumps(rows,indent=2))
