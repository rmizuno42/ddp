#!/usr/bin/env python3
"""Re-express the SAME graph under a cyclic subgroup, without adding vertices."""
from pathlib import Path
import sys,json

def load(p):
 a=[list(map(int,s.split())) for s in p.read_text().splitlines() if s.strip()]
 B,Q,K,D,M=a[0];assert len(a[1:])==M
 return B,Q,K,D,a[1:]
def edges(B,Q,E):
 return {tuple(sorted((a*Q+x,b*Q+(x+t)%Q))) for a,b,t,h in E for x in range(Q)}
def restrict(src,q,dst):
 B,Q,K,D,E=load(src);assert Q%q==0 and 2<=q<Q
 f=Q//q;out=set()
 for a,b,t,h in E:
  for r in range(f):
   na=a*f+r;nb=b*f+(r+t)%f;nt=((r+t)//f)%q
   nh=int(na==nb and nt==q//2 and q%2==0)
   if na>nb:na,nb,nt=nb,na,-nt%q
   if na==nb:nt=min(nt,-nt%q)
   out.add((na,nb,nt,nh))
 out=sorted(out);EB=edges(B*f,q,out)
 perm={a*Q+x:((a*f+x%f)*q+x//f) for a in range(B) for x in range(Q)}
 mapped={tuple(sorted((perm[u],perm[v]))) for u,v in edges(B,Q,E)}
 assert mapped==EB
 deg=[0]*(B*Q)
 for a,b in EB:assert a!=b;deg[a]+=1;deg[b]+=1
 assert all(z==K for z in deg)
 dst.write_text(f'{B*f} {q} {K} {D} {len(out)}\n'+''.join(' '.join(map(str,e))+'\n' for e in out))
 report=dict(source=str(src),output=str(dst),old_quotient_order=B,old_cyclic_order=Q,new_quotient_order=B*f,new_cyclic_order=q,vertices_unchanged=B*Q,edges_checked=len(EB),isomorphism_verified=True,map_formula='(a,x) -> (a*f + x%f, x//f), f=Q/q')
 dst.with_suffix('.restriction.json').write_text(json.dumps(report,indent=2)+'\n')
 print(report)
if __name__=='__main__':restrict(Path(sys.argv[1]),int(sys.argv[2]),Path(sys.argv[3]))
