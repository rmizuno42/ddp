// Simultaneous fixed-order design using the dihedral voltage group D_{Q/2}.
// Element a+b*m denotes r^a s^b; multiplication (a,b)(c,d)=(a+(-1)^b c,b+d).
// Every run creates the full prescribed vertex set from scratch; no graph input.
#include <bits/stdc++.h>
using namespace std;
using U=uint64_t;
struct Edge {int a,b,t; bool half;};
struct Arc {int b,t;};
int B,Q,K,D; U full; vector<Edge> E,bestE; vector<vector<Arc>> adj;
mt19937_64 rng; long long iters=0,evals=0; int best=INT_MAX; string prefix;
int mod(int a){int m=Q/2; a%=m;return a<0?a+m:a;}
int mul(int a,int b){int m=Q/2;return mod(a%m+(a/m?-1:1)*(b%m))+m*((a/m)^(b/m));}
int neg(int t){int m=Q/2;return t>=m?t:mod(-t);}
int invol(){int m=Q/2;int z=rng()%(m+(m%2==0));return z<m?m+z:m/2;}
inline U rot(U x,int t){int m=Q/2;U mask=(1ULL<<m)-1;return t?((x<<t)|(x>>(m-t)))&mask:x;}
inline U shift(U x,int t){int m=Q/2;U mask=(1ULL<<m)-1;U a=rot(x&mask,t%m),b=rot(x>>m,mod(-t));return t>=m?b|(a<<m):a|(b<<m);}
Edge orient(Edge e){if(rng()&1){swap(e.a,e.b);e.t=neg(e.t);}return e;}
bool build(){
 adj.assign(B,{});for(auto e:E){
  if(e.a<0||e.a>=B||e.b<0||e.b>=B||e.t<0||e.t>=Q)return false;
  if(e.a==e.b && e.t==0)return false;
  if(e.half && !(e.a==e.b&&e.t!=0&&e.t==neg(e.t)))return false;
  if(!e.half && e.a==e.b && e.t==neg(e.t))return false;
  for(auto ar:adj[e.a])if(ar.b==e.b&&ar.t==e.t)return false;
  adj[e.a].push_back({e.b,e.t});
  if(!e.half){for(auto ar:adj[e.b])if(ar.b==e.a&&ar.t==neg(e.t))return false;adj[e.b].push_back({e.a,neg(e.t)});}
 }
 for(auto a:adj)if(int(a.size())!=K)return false;
 return true;
}
int score(int cutoff=INT_MAX){
 ++evals;int total=0;U r[256],r2[256];
 for(int s=0;s<B;s++){
  fill(r,r+B,0);r[s]=1;
  for(int d=0;d<D;d++){
   copy(r,r+B,r2);
   for(int a=0;a<B;a++)if(r[a])for(auto ar:adj[a])r2[ar.b]|=shift(r[a],ar.t);
   copy(r2,r2+B,r);
  }
  for(int j=0;j<B;j++)total+=Q-__builtin_popcountll(r[j]);
  if(total>cutoff)return total;
 }
 return total;
}
void fresh(){
 for(;;){E.clear();vector<int>stubs;
  int semi=(B*K)%2;
  for(int i=0;i<B;i++)for(int j=0;j<K-(semi&&i==0);j++)stubs.push_back(i);
  if(semi)E.push_back({0,0,invol(),true});
  shuffle(stubs.begin(),stubs.end(),rng);
  for(int i=0;i<(int)stubs.size();i+=2)E.push_back({stubs[i],stubs[i+1],int(rng()%Q),false});
  if(build())return;
 }
}
void save(){
 ofstream f(prefix+".voltage");f<<B<<' '<<Q<<' '<<K<<' '<<D<<' '<<bestE.size()<<'\n';
 for(auto e:bestE)f<<e.a<<' '<<e.b<<' '<<e.t<<' '<<e.half<<'\n';
 set<pair<int,int>>es;
 for(auto e:bestE)for(int x=0;x<Q;x++){int a=e.a*Q+x,b=e.b*Q+mul(x,e.t);if(a>b)swap(a,b);if(a!=b)es.emplace(a,b);}
 ofstream g(prefix+".edges");g<<B*Q<<'\n';for(auto [a,b]:es)g<<a<<' '<<b<<'\n';
 ofstream j(prefix+".json");j<<"{\"order\":"<<B*Q<<",\"degree\":"<<K<<",\"target_diameter\":"<<D<<",\"quotient_order\":"<<B<<",\"dihedral_order\":"<<Q<<",\"orbit_defect\":"<<best<<",\"bad_unordered_pairs\":"<<(long long)best*Q/2<<",\"iterations\":"<<iters<<",\"evaluations\":"<<evals<<",\"valid\":"<<(best==0?"true":"false")<<"}\n";
}
void change(){
 int typ=rng()%100;
 if(typ<45){int i=rng()%E.size();E[i].t=E[i].half?invol():rng()%Q;}
 else if(typ<96){int i=rng()%E.size(),j=rng()%E.size();if(i==j)return;
  Edge a=orient(E[i]),b=orient(E[j]);
  if(a.half&&b.half){E[i]={a.a,b.a,int(rng()%Q),false};E.erase(E.begin()+j);}
  else if(a.half||b.half){if(b.half){swap(a,b);swap(i,j);}E[i]={b.a,b.a,invol(),true};E[j]={a.a,b.b,int(rng()%Q),false};}
  else{E[i]={a.a,b.a,int(rng()%Q),false};E[j]={a.b,b.b,int(rng()%Q),false};}
 }
 else if(Q%2==0){int i=rng()%E.size();auto e=E[i];if(e.half||e.a==e.b)return;E[i]={e.a,e.a,invol(),true};E.push_back({e.b,e.b,invol(),true});}
 else{int i=rng()%E.size(),j=rng()%E.size();if(E[i].half||E[j].half)return;E[i].t=rng()%Q;E[j].t=rng()%Q;}
}
int main(int ac,char**av){
 if(ac<8){cerr<<"quotient_order dihedral_order degree diameter seconds seed output_prefix [period] [temperature]\n";return 2;}
 B=stoi(av[1]);Q=stoi(av[2]);K=stoi(av[3]);D=stoi(av[4]);double secs=stod(av[5]);rng.seed(stoull(av[6]));prefix=av[7];
 long long period=ac>8?stoll(av[8]):50000;double initialT=ac>9?stod(av[9]):max(2.0,0.035*B*Q);
 if(B>255||Q<4||Q>62||Q%2||K<2||K>9||(B*Q*K)%2){cerr<<"bad parameters\n";return 3;}
 full=(1ULL<<Q)-1;fresh();int cur=score();best=cur;bestE=E;save();auto start=chrono::steady_clock::now();uniform_real_distribution<double>U01(0,1);int cycle=0;
 cerr<<"INITIAL n="<<B*Q<<" B="<<B<<" Q="<<Q<<" K="<<K<<" D="<<D<<" defect="<<cur<<"\n";
 while(best && chrono::duration<double>(chrono::steady_clock::now()-start).count()<secs){
  if(iters&&iters%period==0){cycle++;if(cycle%4==0)fresh();else{E=bestE;for(int z=0;z<3+cycle%13;z++){auto old=E;change();if(!build())E=old;}build();}cur=score();}
  auto old=E;change();iters++;if(!build()){E=old;continue;}
  double phase=double(iters%period)/period;double T=initialT*pow(0.012,phase);
  int cutoff=cur+int(-T*log(max(1e-15,U01(rng))));int next=score(cutoff);
  if(next<=cutoff){cur=next;if(cur<best){best=cur;bestE=E;save();cerr<<"BEST defect="<<best<<" bad_pairs="<<(long long)best*Q/2<<" iter="<<iters<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;}}
  else E=old;
 }
 E=bestE;if(!build()||score()!=best)abort();save();cerr<<"DONE iterations="<<iters<<" evaluations="<<evals<<" best_defect="<<best<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
 return best==0?0:1;
}
