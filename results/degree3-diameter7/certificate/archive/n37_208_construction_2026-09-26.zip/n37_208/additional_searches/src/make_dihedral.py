from pathlib import Path
r=Path(__file__).parent
s=(r/'cyclic_design.cpp').read_text()
s=s.replace('// Simultaneous design of a quotient graph and its cyclic voltages.','// Simultaneous fixed-order design using the dihedral voltage group D_{Q/2}.\n// Element a+b*m denotes r^a s^b; multiplication (a,b)(c,d)=(a+(-1)^b c,b+d).')
s=s.replace('inline U shift(U x,int t){return t?((x<<t)|(x>>(Q-t)))&full:x;}\nint neg(int t){return t?Q-t:0;}', '''int mod(int a){int m=Q/2; a%=m;return a<0?a+m:a;}
int mul(int a,int b){int m=Q/2;return mod(a%m+(a/m?-1:1)*(b%m))+m*((a/m)^(b/m));}
int neg(int t){int m=Q/2;return t>=m?t:mod(-t);}
int invol(){int m=Q/2;int z=rng()%(m+(m%2==0));return z<m?m+z:m/2;}
inline U rot(U x,int t){int m=Q/2;U mask=(1ULL<<m)-1;return t?((x<<t)|(x>>(m-t)))&mask:x;}
inline U shift(U x,int t){int m=Q/2;U mask=(1ULL<<m)-1;U a=rot(x&mask,t%m),b=rot(x>>m,mod(-t));return t>=m?b|(a<<m):a|(b<<m);}''')
s=s.replace('Q%2==0&&e.a==e.b&&e.t==Q/2','e.a==e.b&&e.t!=0&&e.t==neg(e.t)')
s=s.replace('E.push_back({0,0,Q/2,true})','E.push_back({0,0,invol(),true})')
s=s.replace('if(E[i].half)return;E[i].t=rng()%Q;', 'E[i].t=E[i].half?invol():rng()%Q;')
s=s.replace('Q/2,true','invol(),true')
s=s.replace('(x+e.t)%Q','mul(x,e.t)')
s=s.replace('Q<2||Q>63', 'Q<4||Q>62||Q%2')
s=s.replace('cyclic_order','dihedral_order')
(r/'dihedral_design.cpp').write_text(s)
# Transform the targeted variant using exact noncommutative multiplication.
s=(r/'targeted_design.cpp').read_text()
a=s.index('U shift(');b=s.index('bool build()',a)
s=s[:a]+'''int mod(int a){int m=Q/2;a%=m;return a<0?a+m:a;}
int mul(int a,int b){int m=Q/2;return mod(a%m+(a/m?-1:1)*(b%m))+m*((a/m)^(b/m));}
int neg(int t){return t>=Q/2?t:mod(-t);}
int invol(){int m=Q/2;int z=rng()%(m+(m%2==0));return z<m?m+z:m/2;}
U rot(U x,int t){int m=Q/2;U mask=(1ULL<<m)-1;return t?((x<<t)|(x>>(m-t)))&mask:x;}
U shift(U x,int t){int m=Q/2;U mask=(1ULL<<m)-1;U a=rot(x&mask,t%m),b=rot(x>>m,mod(-t));return t>=m?b|(a<<m):a|(b<<m);}
''' + s[b:]
s=s.replace('Q%2==0&&e.a==e.b&&e.t==Q/2','e.a==e.b&&e.t!=0&&e.t==neg(e.t)')
s=s.replace('Q/2,true','invol(),true')
s=s.replace('if(!E[i].half)E[i].t=rng()%Q;', 'E[i].t=E[i].half?invol():rng()%Q;')
s=s.replace('mod(t+b.t-a.t)', 'mul(mul(neg(a.t),t),b.t)')
s=s.replace('t=mod(t+e.t)', 't=mul(t,e.t)')
s=s.replace('int t=mod(y-x)', 'int t=mul(neg(x),y)')
s=s.replace('(x+e.t)%Q', 'mul(x,e.t)')
s=s.replace('Q<2||Q>63','Q<4||Q>62||Q%2')
s='// Dihedral group version. Element a+b*m denotes r^a s^b.\n'+s
(r/'dihedral_targeted.cpp').write_text(s)
