// Path/matching voltage construction family.
// Simultaneous design of a quotient graph and its cyclic voltages.
// Every run creates the full prescribed vertex set from scratch; no graph input.
#include <bits/stdc++.h>
using namespace std;
using U=uint64_t;
struct Edge {int a,b,t; bool half;};
struct Arc {int b,t;};
int B,Q,K,D; U full; vector<Edge> E,bestE; vector<vector<Arc>> adj;
mt19937_64 rng; long long iters=0,evals=0; int best=INT_MAX; string prefix;
inline U shift(U x,int t){return t?((x<<t)|(x>>(Q-t)))&full:x;}
int neg(int t){return t?Q-t:0;}
Edge orient(Edge e){if(rng()&1){swap(e.a,e.b);e.t=neg(e.t);}return e;}
bool build(){
 adj.assign(B,{});for(auto e:E){
  if(e.a<0||e.a>=B||e.b<0||e.b>=B||e.t<0||e.t>=Q)return false;
  if(e.a==e.b && e.t==0)return false;
  if(e.half && !(Q%2==0&&e.a==e.b&&e.t==Q/2))return false;
  if(!e.half && e.a==e.b && e.t==neg(e.t))return false;
  for(auto ar:adj[e.a])if(ar.b==e.b&&ar.t==e.t)return false;
  adj[e.a].push_back({e.b,e.t});
  if(!e.half){for(auto ar:adj[e.b])if(ar.b==e.a&&ar.t==neg(e.t))return false;adj[e.b].push_back({e.a,neg(e.t)});}
 }
 for(auto a:adj)if(int(a.size())!=K)return false;
 return true;
}
int score(int cutoff=INT_MAX){
 ++evals;int total=0;U r[256],r2[256];
 for(int s=0;s<B;s++){
  fill(r,r+B,0);r[s]=1;
  for(int d=0;d<D;d++){
   copy(r,r+B,r2);
   for(int a=0;a<B;a++)if(r[a])for(auto ar:adj[a])r2[ar.b]|=shift(r[a],ar.t);
   copy(r2,r2+B,r);
  }
  for(int j=0;j<B;j++)total+=Q-__builtin_popcountll(r[j]);
  if(total>cutoff)return total;
 }
 return total;
}
// A path on B orbit labels, a cycle at the first end, a matching
// inside the last orbit, and an independently chosen perfect matching of 1..B-1.
// The complete B*Q vertex set is fixed before any edges are designed.
void fresh(){
 for(;;){
  E.clear();E.push_back({0,0,1,false});E.push_back({B-1,B-1,Q/2,true});
  for(int i=0;i<B-1;i++)E.push_back({i,i+1,0,false});
  vector<int>v;for(int i=1;i<B;i++)v.push_back(i);shuffle(v.begin(),v.end(),rng);
  for(int i=0;i<B-1;i+=2)E.push_back({v[i],v[i+1],int(rng()%Q),false});
  if(build())return;
 }
}
void save(){
 ofstream f(prefix+".voltage");f<<B<<' '<<Q<<' '<<K<<' '<<D<<' '<<bestE.size()<<'\n';
 for(auto e:bestE)f<<e.a<<' '<<e.b<<' '<<e.t<<' '<<e.half<<'\n';
 set<pair<int,int>>es;
 for(auto e:bestE)for(int x=0;x<Q;x++){int a=e.a*Q+x,b=e.b*Q+(x+e.t)%Q;if(a>b)swap(a,b);if(a!=b)es.emplace(a,b);}
 ofstream g(prefix+".edges");g<<B*Q<<'\n';for(auto [a,b]:es)g<<a<<' '<<b<<'\n';
 ofstream j(prefix+".json");j<<"{\"order\":"<<B*Q<<",\"degree\":"<<K<<",\"target_diameter\":"<<D<<",\"quotient_order\":"<<B<<",\"cyclic_order\":"<<Q<<",\"orbit_defect\":"<<best<<",\"bad_unordered_pairs\":"<<(long long)best*Q/2<<",\"iterations\":"<<iters<<",\"evaluations\":"<<evals<<",\"valid\":"<<(best==0?"true":"false")<<"}\n";
}
void change(){
 int start=B+1,m=(B-1)/2,typ=rng()%100;
 int i=start+rng()%m;
 if(typ<42){E[i].t=rng()%Q;return;}
 int j=start+rng()%m;if(i==j)return;
 if(typ<92){
  Edge a=orient(E[i]),b=orient(E[j]);int t=rng()%Q;
  E[i]={a.a,b.a,t,false};
  E[j]={a.b,b.b,(t+b.t+Q-a.t)%Q,false};
 }else{E[i].t=rng()%Q;E[j].t=rng()%Q;}
}
int main(int ac,char**av){
 if(ac<8){cerr<<"quotient_order cyclic_order degree diameter seconds seed output_prefix [period] [temperature]\n";return 2;}
 B=stoi(av[1]);Q=stoi(av[2]);K=stoi(av[3]);D=stoi(av[4]);double secs=stod(av[5]);rng.seed(stoull(av[6]));prefix=av[7];
 long long period=ac>8?stoll(av[8]):50000;double initialT=ac>9?stod(av[9]):max(2.0,0.035*B*Q);
 if(B>255||Q<2||Q>63||K<2||K>9||(B*Q*K)%2){cerr<<"bad parameters\n";return 3;}
 if(B%2!=1||Q%2||K!=3)return 4;full=(1ULL<<Q)-1;fresh();int cur=score();best=cur;bestE=E;save();auto start=chrono::steady_clock::now();uniform_real_distribution<double>U01(0,1);int cycle=0;
 cerr<<"INITIAL n="<<B*Q<<" B="<<B<<" Q="<<Q<<" K="<<K<<" D="<<D<<" defect="<<cur<<"\n";
 while(best && chrono::duration<double>(chrono::steady_clock::now()-start).count()<secs){
  if(iters&&iters%period==0){cycle++;if(cycle%4==0)fresh();else{E=bestE;for(int z=0;z<3+cycle%13;z++){auto old=E;change();if(!build())E=old;}build();}cur=score();}
  auto old=E;change();iters++;if(!build()){E=old;continue;}
  double phase=double(iters%period)/period;double T=initialT*pow(0.012,phase);
  int cutoff=cur+int(-T*log(max(1e-15,U01(rng))));int next=score(cutoff);
  if(next<=cutoff){cur=next;if(cur<best){best=cur;bestE=E;save();cerr<<"BEST defect="<<best<<" bad_pairs="<<(long long)best*Q/2<<" iter="<<iters<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;}}
  else E=old;
 }
 E=bestE;if(!build()||score()!=best)abort();save();cerr<<"DONE iterations="<<iters<<" evaluations="<<evals<<" best_defect="<<best<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
 return best==0?0:1;
}
