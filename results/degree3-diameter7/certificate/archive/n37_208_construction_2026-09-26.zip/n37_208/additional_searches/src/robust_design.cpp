// Fixed-order quotient/voltage design. A move redesigns whole edge orbits.
// Optional input is a failed candidate of the SAME order, never a smaller record.
#include<bits/stdc++.h>
using namespace std;using U=uint64_t;struct Edge{int a,b,t;bool half;};struct Arc{int b,t,e;bool rev;};struct Bad{int a,b,t;};
int B,Q,K,D;U full;vector<Edge>E,bestE;vector<vector<Arc>>adj;vector<Bad>missing,currentMissing;mt19937_64 rng;long long iter=0,evals=0;int best=INT_MAX,bestsec=INT_MAX;string pre;double weight=.008;
U shift(U x,int t){return t?((x<<t)|(x>>(Q-t)))&full:x;}int neg(int t){return t?Q-t:0;}int mod(int t){t%=Q;return t<0?t+Q:t;}
bool build(){adj.assign(B,{});for(int i=0;i<(int)E.size();i++){auto e=E[i];if(e.a<0||e.a>=B||e.b<0||e.b>=B||e.t<0||e.t>=Q)return false;if(e.a==e.b&&e.t==0)return false;if(e.half&&!(Q%2==0&&e.a==e.b&&e.t==Q/2))return false;if(!e.half&&e.a==e.b&&e.t==neg(e.t))return false;for(auto a:adj[e.a])if(a.b==e.b&&a.t==e.t)return false;adj[e.a].push_back({e.b,e.t,i,false});if(!e.half){for(auto a:adj[e.b])if(a.b==e.a&&a.t==neg(e.t))return false;adj[e.b].push_back({e.a,neg(e.t),i,true});}}for(auto a:adj)if((int)a.size()!=K)return false;return true;}
// Primary objective: missing ordered orbit targets at the desired diameter.
// Secondary: targets first reached at D with exactly one penultimate neighbour.
// This is not a mathematical certificate; the final graph is checked separately.
pair<int,int> score(double cutoff=1e30){
 evals++;missing.clear();U x[256],y[256],twice[256];int bad=0,sec=0;
 for(int s=0;s<B;s++){
  fill(x,x+B,0);x[s]=1;
  for(int d=1;d<=D;d++){
   copy(x,x+B,y);
   if(d==D)copy(x,x+B,twice);
   for(int a=0;a<B;a++)if(x[a])for(auto z:adj[a]){
    U v=shift(x[a],z.t);
    if(d==D)twice[z.b]|=y[z.b]&v;
    y[z.b]|=v;
   }
   copy(y,y+B,x);
  }
  for(int j=0;j<B;j++){
   sec+=__builtin_popcountll(x[j]&~twice[j]);
   U z=full^x[j];bad+=__builtin_popcountll(z);
   while(z){int t=__builtin_ctzll(z);missing.push_back({s,j,t});z&=z-1;}
  }
  if(bad+weight*sec>cutoff)return{bad,sec};
 }
 return{bad,sec};
}
Edge orient(Edge a){if(rng()&1){swap(a.a,a.b);a.t=neg(a.t);}return a;}
void randommove(){int typ=rng()%100;if(typ<40){int i=rng()%E.size();if(!E[i].half)E[i].t=rng()%Q;}else if(typ<96){int i=rng()%E.size(),j=rng()%E.size();if(i==j)return;Edge a=orient(E[i]),b=orient(E[j]);if(a.half&&b.half){E[i]={a.a,b.a,int(rng()%Q),false};E.erase(E.begin()+j);}else if(a.half||b.half){if(b.half){swap(a,b);swap(i,j);}E[i]={b.a,b.a,Q/2,true};E[j]={a.a,b.b,int(rng()%Q),false};}else{int t=rng()%Q;E[i]={a.a,b.a,t,false};E[j]={a.b,b.b,rng()%2?mod(t+b.t-a.t):int(rng()%Q),false};}}else if(Q%2==0){int i=rng()%E.size();auto a=E[i];if(!a.half&&a.a!=a.b){E[i]={a.a,a.a,Q/2,true};E.push_back({a.b,a.b,Q/2,true});}}else{int i=rng()%E.size(),j=rng()%E.size();E[i].t=rng()%Q;E[j].t=rng()%Q;}}
bool targetmove(){if(currentMissing.empty())return false;auto z=currentMissing[rng()%currentMissing.size()];int aa=z.a,bb=z.b,x=0,y=z.t,l=(D-1)/2+int(rng()%3)-1;l=max(0,min(D-1,l));int r=D-1-l;vector<bool>used(E.size(),false);auto walk=[&](int &a,int &t,int steps){int prev=-1;for(int j=0;j<steps;j++){vector<Arc>v;for(auto e:adj[a])if(e.e!=prev)v.push_back(e);if(v.empty())v=adj[a];auto e=v[rng()%v.size()];a=e.b;t=mod(t+e.t);used[e.e]=true;prev=e.e;}};walk(aa,x,l);walk(bb,y,r);if(rng()%100<65){
 vector<Arc> compatible;
 for(auto z:adj[aa])if(z.b==bb&&!used[z.e]&&!E[z.e].half)compatible.push_back(z);
 if(!compatible.empty()){
  auto z=compatible[rng()%compatible.size()];int t=mod(y-x);
  E[z.e].t=z.rev?neg(t):t;return true;
 }
}
vector<Arc>A,C;for(auto e:adj[aa])if(!used[e.e]&&!E[e.e].half)A.push_back(e);for(auto e:adj[bb])if(!used[e.e]&&!E[e.e].half)C.push_back(e);if(A.empty()||C.empty())return false;auto a=A[rng()%A.size()],b=C[rng()%C.size()];if(a.e==b.e)return false;int t=mod(y-x);E[a.e]={aa,bb,t,false};E[b.e]={a.b,b.b,mod(t+b.t-a.t),false};return true;}
void fresh(){for(;;){E.clear();vector<int>st;int semi=(B*K)%2;for(int i=0;i<B;i++)for(int j=0;j<K-(semi&&i==0);j++)st.push_back(i);if(semi)E.push_back({0,0,Q/2,true});shuffle(st.begin(),st.end(),rng);for(int i=0;i<(int)st.size();i+=2)E.push_back({st[i],st[i+1],int(rng()%Q),false});if(build())return;}}
void save(){bestE=E;ofstream f(pre+".voltage");f<<B<<' '<<Q<<' '<<K<<' '<<D<<' '<<E.size()<<'\n';for(auto e:E)f<<e.a<<' '<<e.b<<' '<<e.t<<' '<<e.half<<'\n';set<pair<int,int>>es;for(auto e:E)for(int x=0;x<Q;x++){int a=e.a*Q+x,b=e.b*Q+(x+e.t)%Q;if(a!=b)es.emplace(min(a,b),max(a,b));}ofstream g(pre+".edges");g<<B*Q<<'\n';for(auto[a,b]:es)g<<a<<' '<<b<<'\n';ofstream j(pre+".json");j<<"{\"order\":"<<B*Q<<",\"degree\":"<<K<<",\"target_diameter\":"<<D<<",\"orbit_defect\":"<<best<<",\"bad_pairs\":"<<(long long)best*Q/2<<",\"secondary\":"<<bestsec<<",\"iterations\":"<<iter<<",\"evaluations\":"<<evals<<",\"valid\":"<<(best?"false":"true")<<"}\n";}
int main(int ac,char**av){if(ac<8)return 2;B=stoi(av[1]);Q=stoi(av[2]);K=stoi(av[3]);D=stoi(av[4]);double secs=stod(av[5]);rng.seed(stoull(av[6]));pre=av[7];int period=ac>8?stoi(av[8]):200000;double T0=ac>9?stod(av[9]):5;if(ac>10)weight=stod(av[10]);if(B>255||Q<2||Q>63||(B*Q*K)%2)return 3;full=(1ULL<<Q)-1;
if(ac>11){ifstream f(av[11]);int b,q,k,d,m;f>>b>>q>>k>>d>>m;if(b!=B||q!=Q||k!=K||d!=D)return 4;while(m--){Edge e;f>>e.a>>e.b>>e.t>>e.half;E.push_back(e);}if(!build())return 5;}else fresh();auto[cur,sec]=score();currentMissing=missing;best=cur;bestsec=sec;save();auto start=chrono::steady_clock::now();uniform_real_distribution<double>ur(0,1);int cycles=0;cerr<<"INITIAL bad="<<best<<" secondary="<<sec<<'\n';while(best&&chrono::duration<double>(chrono::steady_clock::now()-start).count()<secs){if(iter&&iter%period==0){cycles++;if(cycles%5==0)fresh();else{E=bestE;build();for(int j=0;j<1+cycles%8;j++){auto old=E;randommove();if(!build())E=old;build();}}tie(cur,sec)=score();currentMissing=missing;}
auto old=E;if(rng()%100<65){if(!targetmove())randommove();}else randommove();iter++;if(!build()){E=old;build();continue;}double T=T0*pow(.002,double(iter%period)/period);double cutoff=cur+weight*sec-T*log(max(1e-15,ur(rng)));auto[s,ss]=score(cutoff);if(s+weight*ss<=cutoff){cur=s;sec=ss;currentMissing=missing;if(s<best||(s==best&&ss<bestsec)){bool low=s<best;best=s;bestsec=ss;save();if(low)cerr<<"BEST defect="<<best<<" bad_pairs="<<(long long)best*Q/2<<" sec="<<ss<<" iter="<<iter<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';}}else{E=old;build();}}
E=bestE;build();auto[s,ss]=score();if(s!=best||ss!=bestsec)abort();save();cerr<<"DONE defect="<<best<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<" iterations="<<iter<<'\n';return best?1:0;}
