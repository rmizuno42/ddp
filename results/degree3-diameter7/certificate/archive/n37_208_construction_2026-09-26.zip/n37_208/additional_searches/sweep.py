import subprocess,pathlib,json
r=pathlib.Path(__file__).parent
configs=[(27,8,3,7,45,926012,'c216_b27',50000,10),(21,10,3,7,45,926013,'c210_b21',50000,9),(12,18,3,7,45,926014,'c216_b12',50000,9),(14,16,3,7,45,926015,'c224_b14',50000,10),(16,14,3,7,45,926016,'c224_b16',50000,10),(13,18,3,7,45,926017,'c234_b13',50000,10)]
for b,q,k,d,sec,seed,name,period,T in configs:
 cmd=[str(r/'cyclic_design'),str(b),str(q),str(k),str(d),str(sec),str(seed),str(r/'runs'/name),str(period),str(T)]
 with open(r/'runs'/f'{name}.log','w') as log:
  p=subprocess.Popen(cmd,stdout=log,stderr=log,stdin=subprocess.DEVNULL)
  with open(r/'runs'/'commands.jsonl','a') as lf:lf.write(json.dumps(dict(name=name,pid=p.pid,args=cmd))+'\n')
  code=p.wait()
 print(name,code,flush=True)
