#!/usr/bin/env python3
"""Optional deterministic-iteration replay of the discovery, requiring g++."""
from pathlib import Path
import subprocess,tempfile,json,time

def replay():
    root=Path(__file__).parent;source=(root/'cyclic_design.cpp').read_text()
    old='while(best && chrono::duration<double>(chrono::steady_clock::now()-start).count()<secs)'
    assert source.count(old)==1
    source=source.replace(old,'while(best && iters<8742000LL)')
    with tempfile.TemporaryDirectory(prefix='n37_208_replay_') as tmp:
        d=Path(tmp);cpp=d/'design.cpp';cpp.write_text(source);binary=d/'design'
        subprocess.run(['g++','-O3','-march=native','-std=c++17',str(cpp),'-o',str(binary)],check=True)
        command=[str(binary),'13','16','3','7','10000','926001',str(d/'result'),'30000','9']
        start=time.monotonic();p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=True);elapsed=time.monotonic()-start
        voltage=(d/'result.voltage').read_bytes();edges=(d/'result.edges').read_bytes()
        assert voltage==(root/'c208_b13.voltage').read_bytes()
        assert edges==(root/'c208_b13.edges').read_bytes()
        metadata=json.loads((d/'result.json').read_text())
        assert metadata['iterations']==8742000 and metadata['valid'] is True
        result=dict(seed=926001,iterations=8742000,voltage_table_identical=True,edge_file_identical=True,used_existing_graph_input=False,measured_seconds=elapsed,valid=True)
        print(json.dumps(result,indent=2))
        print('PASS: replay from a fresh vertex set reproduces the entire frozen voltage and edge files.')
        return result
if __name__=='__main__':replay()
