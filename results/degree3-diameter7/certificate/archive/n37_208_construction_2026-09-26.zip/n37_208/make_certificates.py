#!/usr/bin/env python3
from collections import deque
from pathlib import Path
import json
from construct import construct

def generate():
    n,E=construct();adj=[[] for _ in range(n)]
    for a,b in sorted(E):adj[a].append(b);adj[b].append(a)
    trees=[]
    for root in range(0,n,16):
        depth=[-1]*n;parent=[-1]*n;depth[root]=0;parent[root]=root;todo=deque([root])
        while todo:
            a=todo.popleft()
            for b in sorted(adj[a]):
                if depth[b]<0:depth[b]=depth[a]+1;parent[b]=a;todo.append(b)
        assert min(depth)==0 and max(depth)<=7
        trees.append(dict(root=root,parent=parent,depth=depth))
    result=dict(vertices=n,maximum_depth=7,trees=trees)
    (Path(__file__).parent/'certificates/thirteen_trees.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':generate()
