#!/usr/bin/env python3
"""Verify the entire lower-bound certificate using only Python's standard library."""
from pathlib import Path
import argparse,hashlib,json
import construct,verify,verify_voltage,check_certificate,verify_structure,verify_normalization
ROOT=Path(__file__).parent

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--all-candidates',action='store_true');args=parser.parse_args()
    hashes=0
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,('hash mismatch',name)
        hashes+=1
    print(f'PASS: SHA-256 checks for {hashes} frozen files.')
    n,E=construct.construct();A,F=verify.read_edges(ROOT/'graphs/n37_208.edges')
    assert n==208 and len(E)==312 and E==F and len(A)==n
    lines=[l for l in (ROOT/'graphs/n37_208.adjlist').read_text().splitlines() if l and not l.startswith('#')]
    assert len(lines)==208
    for v,line in enumerate(lines):
        row=list(map(int,line.split()));assert row[0]==v and len(row)==4 and set(row[1:])==A[v]
    assert all(check_certificate.neighbours(v)==A[v] for v in range(n))
    print('PASS: formula, full adjacency list, edge list, and independent neighbour function agree.')
    result,spheres=verify.verify(ROOT/'graphs/n37_208.edges',3,7)
    assert result['valid'] and result['diameter']==7 and result['degree_histogram']=={3:208}
    frozen=json.loads((ROOT/'reports/n37_208.json').read_text())
    assert json.loads(json.dumps(result))==frozen
    print('PASS: independent all-pairs BFS: all 21,528 unordered pairs have distance at most 7.')
    voltage=verify_voltage.verify()
    for i,arcs in enumerate(voltage['arcs']):
        assert {(16*j+t) for j,t in arcs}==A[16*i]
        actual=[spheres[16*i].get(j,0) for j in range(8)]
        assert voltage['roots'][i]['spheres']==actual
    assert json.loads(json.dumps(voltage))==json.loads((ROOT/'reports/voltage_verification.json').read_text())
    print('PASS: 169 complete modular reachability sets independently prove the upper bound.')
    assert check_certificate.check()['valid']
    print('PASS: 13 depth-7 spanning trees and cyclic translation; 208 > 190 excludes diameter <=6.')
    assert verify_normalization.check()['valid']
    print('PASS: normalization is only a relabeling, with no vertices or edges added.')
    assert verify_structure.check()['valid']
    print('PASS: girth 9 and full automorphism group C16.')
    if args.all_candidates:
        summary=json.loads((ROOT/'additional_searches/summary.json').read_text());count=0
        for row in summary['search_runs']:
            r,_=verify.verify(ROOT/'additional_searches/runs'/f"{row['name']}.edges",row['degree'],row['target_diameter'])
            assert r['valid']==row['valid'] and r['diameter']==row['actual_diameter'] and r['bad_pair_count']==row['bad_pair_count'];count+=1
        for row in summary['contraction_checks']:
            name='contract_'+Path(row['source']).stem
            r,_=verify.verify(ROOT/'additional_searches/runs'/f'{name}.edges',4,4)
            assert not r['valid'] and r['diameter']==row['actual_diameter'] and r['bad_pair_count']==row['bad_pairs'];count+=1
        print(f'PASS: {count} search/contraction outputs rechecked, including every explicitly failed candidate.')
    print('VERIFIED: N(3,7) >= 208; a simple cubic graph with diameter 7 and girth 9.')
if __name__=='__main__':main()
