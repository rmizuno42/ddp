#!/usr/bin/env python3
"""Independent all-pairs BFS; no search code or group library required."""
from __future__ import annotations
from collections import Counter, deque
from pathlib import Path
import argparse, hashlib, json

def read_edges(path: Path):
    lines=[line.split('#',1)[0].strip() for line in path.read_text().splitlines()]
    lines=[line for line in lines if line]
    if not lines: raise ValueError('empty file')
    n=int(lines[0]); adj=[set() for _ in range(n)]; seen=set()
    for line in lines[1:]:
        a,b=map(int,line.split())
        if not 0<=a<n or not 0<=b<n or a==b: raise ValueError(f'invalid edge: {line}')
        edge=tuple(sorted((a,b)))
        if edge in seen: raise ValueError(f'duplicate edge: {line}')
        seen.add(edge); adj[a].add(b); adj[b].add(a)
    return adj,seen

def verify(path: Path, degree: int, diameter: int):
    adj,es=read_edges(path);n=len(adj);hist=Counter();ecc=Counter();bad=[];spheres=[]
    connected=True
    for s in range(n):
        d=[-1]*n;d[s]=0;queue=deque([s])
        while queue:
            a=queue.popleft()
            for b in adj[a]:
                if d[b]<0:d[b]=d[a]+1;queue.append(b)
        connected &= (-1 not in d)
        ecc[max(d) if -1 not in d else -1]+=1
        spheres.append(dict(sorted(Counter(d).items())))
        for t in range(s+1,n):
            hist[d[t]]+=1
            if d[t]<0 or d[t]>diameter:bad.append([s,t,d[t]])
    dg=Counter(map(len,adj));dig=hashlib.sha256(''.join(f'{a} {b}\n' for a,b in sorted(es)).encode()).hexdigest()
    result=dict(vertices=n,edges=len(es),simple=True,connected=connected,
                degree_histogram=dict(sorted(dg.items())),max_degree=max(dg),
                diameter=max(ecc) if connected else None,eccentricity_histogram=dict(sorted(ecc.items())),
                unordered_distance_histogram=dict(sorted(hist.items())),
                pairs_checked=n*(n-1)//2,bad_pair_count=len(bad),bad_pairs=bad,
                valid=connected and max(dg)<=degree and not bad,
                requested_degree=degree,requested_diameter=diameter,
                canonical_edge_sha256=dig,file_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    return result,spheres

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('file',type=Path);p.add_argument('--degree',type=int,required=True);p.add_argument('--diameter',type=int,required=True);p.add_argument('--out',type=Path)
    a=p.parse_args();out,_=verify(a.file,a.degree,a.diameter);text=json.dumps(out,indent=2)+'\n'
    if a.out:a.out.write_text(text)
    print(text,end='');raise SystemExit(0 if out['valid'] else 1)
