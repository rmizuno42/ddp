#!/usr/bin/env python3
from pathlib import Path
import json
from construct import construct
from verify import read_edges

def check():
    r=Path(__file__).parent;info=json.loads((r/'discovery/normalization.json').read_text())
    order=info['old_orbit_order'];offsets=info['offsets'];scale=info['scale'];inverse={a:i for i,a in enumerate(order)}
    mapping={16*a+x:16*inverse[a]+scale*(x-offsets[inverse[a]])%16 for a in range(13) for x in range(16)}
    assert len(set(mapping.values()))==208
    _,old=read_edges(r/'discovery/c208_b13.edges');n,new=construct()
    assert {tuple(sorted((mapping[a],mapping[b]))) for a,b in old}==new
    rows=[list(map(int,line.split())) for line in (r/'discovery/c208_b13.voltage').read_text().splitlines()]
    assert rows[0]==[13,16,3,7,20]
    from_voltage={tuple(sorted((16*a+x,16*b+(x+t)%16))) for a,b,t,h in rows[1:] for x in range(16)}
    assert from_voltage==old
    return dict(vertices=208,edges_checked=312,relabeling_is_bijection=True,edge_sets_agree=True,vertices_added=0,vertices_deleted=0,edges_changed=0,valid=True)
if __name__=='__main__':
    out=check();(Path(__file__).parent/'reports/normalization_verification.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS: the compact formula only relabels the graph found from scratch.')
