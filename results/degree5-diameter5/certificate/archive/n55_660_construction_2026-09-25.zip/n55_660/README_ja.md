# N(5,5) ≥ 660 — 660頂点の5正則・直径5のグラフ

2026年9月25日。本対話で得られた明示構成と、独立検証の証明書一式です。

**結論：単純無向グラフで、頂点数660、辺数1,650、全頂点の次数5、直径5。**

同日に確認した Comellas の記録表の (5,5) の値650を10頂点上回ります。5+5=10です。最適性や出版上の先取権、記録表への採録・反映を主張するものではありません。

頂点はPSL(2,11)の660個の元です。PGL(2,11)の5個の行列を使う `x -- h*x*s` という規則で全辺を定め、さらに行列で定まるマッチングで5正則にします。既存の記録グラフを入力に用いません。マッチングを加える前のグラフも最大次数5・直径5・660頂点で、単独で下界を証明します。

## 一括検証

Python 3.10以降、標準ライブラリだけで実行できます。

```sh
python3 run_all.py
```

最後に次の行が出力されます。

```
VERIFIED: N(5,5) >= 660; a simple 5-regular certificate is included.
```

計算を全く信用せずに核となる有限群恒等式だけを調べる場合は、外部ファイルを読まない `check_identity.py` を確認して実行してください。列挙される積集合の大きさは5,21,85,341,660です。

## 主要ファイル

| ファイル | 内容 |
|---|---|
| `proof_ja.md` | 一般補題、具体的行列、直径の証明、正則化の証明 |
| `spec.json` | 行列と構成規則の機械可読仕様 |
| `construct.py` | 既存グラフなしで全証明書を生成するコード |
| `check_identity.py` | 他のファイルを読まずに S⁵=PGL(2,11)\PSL(2,11) を検証 |
| `word_certificate.tsv` | 非平方行列式を持つ全660射影行列の5文字の積表示 |
| `verify_factorization.py` | 12点の置換を使う独立検証器、両グラフも独立に再構成 |
| `verify.py` | 群を使わない厳密な辺リスト検査と全頂点対BFS |
| `graphs/n55_660_regular.edges` | 5正則グラフの正規化辺リスト |
| `graphs/n55_660_regular.adjlist` | 同じグラフの全隣接リスト |
| `graphs/n55_660_algebraic.edges` | 正則化前の660頂点・最大次数5・直径5のグラフ |
| `graphs/regular_completion.edges` | 正則化の15辺だけ。単独では連結グラフではない |
| `vertices.tsv` | 0始まりの頂点IDと射影行列の対応 |
| `reports/` | 実際の検証結果 |
| `discovery/` | 任意実行の生成集合探索の再現資料 |
| `SHA256SUMS` | 配布ファイルのハッシュ一覧 |

`.edges` の形式は、1行目が頂点数、以降が `u v`（0≤u<v<660）です。辺は辞書順です。`.adjlist` はコメントを除き、各行が頂点番号とその全ての隣接点です。

正則グラフの次数分布は `{5:660}`、非順序頂点対の距離1〜5の分布は `1650, 6600, 25824, 92292, 91104` です。全217,470対を検査しています。

## 個別の実行例

```sh
python3 check_identity.py
python3 verify_factorization.py
python3 verify.py graphs/n55_660_regular.edges --degree 5 --diameter 5
python3 construct.py --output-dir rebuilt
```

基本グラフの隣接先は `h*x*s` です。`x*s` だけではありません。また、行列は非零スカラー倍を同一視し、行列の最初の非零成分が1になるよう正規化します。

基本の一括検証にはNetworkX、NumPy、SageMath、GAP、インターネット接続は不要です。`reports/networkx_crosscheck.json` は別途行った追加検算の記録で、NetworkXは追試の必須依存ではありません。

記録比較の出典と範囲は `proof_ja.md` および `sources.json` に記載しています。
