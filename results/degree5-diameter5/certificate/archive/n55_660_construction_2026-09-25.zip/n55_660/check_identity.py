#!/usr/bin/env python3
"""Self-contained exact verification of S^5 = PGL(2,11) minus PSL(2,11)."""
P = 11
S = ((1, 0, 0, 10), (1, 1, 4, 10), (1, 5, 3, 10),
     (0, 1, 3, 8), (1, 4, 1, 0))


def multiply(x, y):
    a, b, c, d = x
    e, f, g, h = y
    z = ((a*e+b*g) % P, (a*f+b*h) % P,
         (c*e+d*g) % P, (c*f+d*h) % P)
    inverse = pow(next(v for v in z if v), -1, P)
    return tuple(v * inverse % P for v in z)


nonsquares = {2, 6, 7, 8, 10}
negative = {(1, b, c, d) for b in range(P) for c in range(P)
            for d in range(P) if (d - b*c) % P in nonsquares}
negative |= {(0, 1, c, d) for c in range(1, P) for d in range(P)
             if -c % P in nonsquares}
products = {(1, 0, 0, 1)}
for k in range(1, 6):
    products = {multiply(x, s) for x in products for s in S}
    print(f"|S^{k}| = {len(products)}")
if len(negative) != 660 or products != negative:
    raise SystemExit("FAIL: the group identity does not hold.")
print("PASS: S^5 is exactly the 660-element nonsquare-determinant coset.")
