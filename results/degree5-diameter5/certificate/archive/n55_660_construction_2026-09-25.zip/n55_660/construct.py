#!/usr/bin/env python3
"""Construct a 660-vertex (5,5)-graph directly from projective matrices.

No input graph, search, third-party library, or network access is required.
All graph vertex IDs are lexicographically sorted normalized matrices in PSL(2,11).
"""
from __future__ import annotations
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path

P = 11
Matrix = tuple[int, int, int, int]
I: Matrix = (1, 0, 0, 1)
H: Matrix = (1, 0, 0, 10)
T: Matrix = (0, 1, 10, 0)
S: tuple[Matrix, ...] = (H, (1, 1, 4, 10), (1, 5, 3, 10),
                         (0, 1, 3, 8), (1, 4, 1, 0))
NAMES = "habrR"
SQUARES = {1, 3, 4, 5, 9}
NONSQUARES = {2, 6, 7, 8, 10}


def normalize(m: Matrix) -> Matrix:
    v = tuple(z % P for z in m)
    first = next((z for z in v if z), None)
    if first is None:
        raise ValueError("The zero matrix has no projective class.")
    scale = pow(first, -1, P)
    return tuple(z * scale % P for z in v)  # type: ignore[return-value]


def mul(x: Matrix, y: Matrix) -> Matrix:
    a, b, c, d = x
    e, f, g, h = y
    return normalize((a * e + b * g, a * f + b * h,
                      c * e + d * g, c * f + d * h))


def det(x: Matrix) -> int:
    a, b, c, d = x
    return (a * d - b * c) % P


def inv(x: Matrix) -> Matrix:
    a, b, c, d = x
    if det(x) == 0:
        raise ValueError("A singular matrix is not a group element.")
    return normalize((d, -b, -c, a))


def projective_group() -> list[Matrix]:
    # First nonzero entry is 1. Invertibility excludes the other possible forms.
    first = [(1, b, c, d) for b in range(P) for c in range(P)
             for d in range(P) if (d - b * c) % P]
    second = [(0, 1, c, d) for c in range(1, P) for d in range(P)]
    return sorted(first + second)


def edge_text(n: int, edges: set[tuple[int, int]]) -> str:
    return f"{n}\n" + "".join(f"{u} {v}\n" for u, v in sorted(edges))


def construct(output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    (output / "graphs").mkdir(exist_ok=True)
    (output / "reports").mkdir(exist_ok=True)
    group = projective_group()
    positive = [x for x in group if det(x) in SQUARES]
    negative = {x for x in group if det(x) in NONSQUARES}
    assert len(group) == 1320 and len(positive) == len(negative) == 660
    assert all(det(s) in NONSQUARES for s in S)
    assert {inv(s) for s in S} == set(S)
    assert mul(H, H) == I and mul(T, T) == I and T != I
    assert mul(H, T) == mul(T, H) and det(T) in SQUARES

    # Exactly k factors, not merely the ball of radius k.
    words: dict[Matrix, str] = {I: ""}
    sizes = [1]
    for _ in range(5):
        new: dict[Matrix, str] = {}
        for x in sorted(words):
            for symbol, s in zip(NAMES, S):
                new.setdefault(mul(x, s), words[x] + symbol)
        words = new
        sizes.append(len(words))
    assert sizes == [1, 5, 21, 85, 341, 660]
    assert set(words) == negative
    with (output / "word_certificate.tsv").open("w", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
        writer.writerow(["a", "b", "c", "d", "word"])
        for x in sorted(words):
            writer.writerow([*x, words[x]])

    index = {x: i for i, x in enumerate(positive)}
    adjacency: list[set[int]] = [set() for _ in positive]
    loop_sites: list[tuple[int, str]] = []
    for u, x in enumerate(positive):
        for symbol, s in zip(NAMES, S):
            y = mul(mul(H, x), s)
            v = index[y]
            if u == v:
                loop_sites.append((u, symbol))
            else:
                adjacency[u].add(v)
    assert all(u in adjacency[v] for u in range(660) for v in adjacency[u])
    edges = {(u, v) for u in range(660) for v in adjacency[u] if u < v}
    assert Counter(map(len, adjacency)) == {4: 30, 5: 630}
    assert len(edges) == 1635
    assert len(loop_sites) == 30
    deficient = {u for u, _ in loop_sites}

    # Optional algebraic regular completion: x <-> T*x precisely at loop sites.
    # This is a globally specified matching, not an edge-search operation.
    matching: set[tuple[int, int]] = set()
    for u in sorted(deficient):
        v = index[mul(T, positive[u])]
        assert v in deficient and v != u and v not in adjacency[u]
        matching.add(tuple(sorted((u, v))))
    assert len(matching) == 15
    regular = edges | matching
    assert Counter(z for edge in regular for z in edge) == {i: 5 for i in range(660)}

    with (output / "vertices.tsv").open("w", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
        writer.writerow(["id", "a", "b", "c", "d"])
        for u, x in enumerate(positive):
            writer.writerow([u, *x])
    graph_hashes = {}
    for name, es in [("n55_660_algebraic", edges), ("n55_660_regular", regular)]:
        text = edge_text(660, es)
        (output / "graphs" / f"{name}.edges").write_text(text)
        graph_hashes[name] = hashlib.sha256(text.encode()).hexdigest()
        neighbors = [set() for _ in range(660)]
        for u, v in es:
            neighbors[u].add(v)
            neighbors[v].add(u)
        adjacency_text = "# 660 vertices; each row lists vertex ID followed by all neighbors.\n"
        adjacency_text += "".join(" ".join(map(str, [u, *sorted(neighbors[u])])) + "\n"
                                  for u in range(660))
        (output / "graphs" / f"{name}.adjlist").write_text(adjacency_text)
    (output / "graphs" / "regular_completion.edges").write_text(edge_text(660, matching))
    spec = {
        "prime": P,
        "projective_normalization": "First nonzero entry of (a,b,c,d) equals 1 modulo 11.",
        "vertex_order": "Lexicographically sorted nonsingular normalized matrices with square determinant.",
        "fold_involution_h": H,
        "generators": dict(zip(NAMES, S)),
        "edge_rule": "x -- h*x*s for s in S, with loops removed and edges undirected.",
        "optional_completion_t": T,
        "optional_completion_rule": "For each x with h*x*s=x for some s in S, add x -- t*x.",
    }
    (output / "spec.json").write_text(json.dumps(spec, indent=2) + "\n")
    report = {
        "group_order": len(group), "positive_coset_size": len(positive),
        "negative_coset_size": len(negative), "exact_product_set_sizes_k_0_to_5": sizes,
        "factorization_identity": "S^5 = PGL(2,11) minus PSL(2,11)",
        "loop_site_counts_by_generator": dict(sorted(Counter(s for _, s in loop_sites).items())),
        "algebraic_edges": len(edges), "regular_completion_edges": len(matching),
        "regular_edges": len(regular), "graph_sha256": graph_hashes,
    }
    (output / "reports" / "construction.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    try:
        report = construct(args.output_dir)
    except (OSError, ValueError, AssertionError) as error:
        raise SystemExit(f"Construction failed: {error}") from error
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
