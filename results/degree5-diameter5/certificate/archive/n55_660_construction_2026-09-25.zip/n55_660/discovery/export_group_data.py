#!/usr/bin/env python3
"""Rebuild the original search's group tables, using no input graph or data file.

The generators act on P^1(F_11) as z+1, -1/z, and 2*z. Original discovery
labels come from breadth-first enumeration with right composition in that order.
The optional search uses C++17; the final construction/verification does not.
"""
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path


def build(prefix: Path) -> dict:
    generators = [tuple((z + 1) % 11 for z in range(11)) + (11,),
                  (11,) + tuple(-pow(z, -1, 11) % 11 for z in range(1, 11)) + (0,),
                  tuple(2 * z % 11 for z in range(11)) + (11,)]
    group = [tuple(range(12))]
    parity = [0]
    index = {group[0]: 0}
    position = 0
    while position < len(group):
        x = group[position]
        for generator, bit in zip(generators, (0, 0, 1)):
            y = tuple(x[generator[z]] for z in range(12))
            value = parity[position] ^ bit
            if y not in index:
                index[y] = len(group)
                group.append(y)
                parity.append(value)
            elif parity[index[y]] != value:
                raise ValueError("Inconsistent determinant character.")
        position += 1
    if len(group) != 1320 or sum(parity) != 660:
        raise ValueError("The group enumeration is incorrect.")
    n = len(group)
    multiplication = [[index[tuple(x[y[z]] for z in range(12))] for y in group] for x in group]
    inverses = [row.index(0) for row in multiplication]
    prefix.parent.mkdir(parents=True, exist_ok=True)
    with prefix.open("w") as stream:
        stream.write(f"{n} {n}\n")
        for row in multiplication:
            stream.write(" ".join(map(str, row)) + "\n")
        stream.write(" ".join(map(str, inverses)) + "\n")
        for conjugator in range(n):
            row = [multiplication[multiplication[inverses[conjugator]][x]][conjugator]
                   for x in range(n)]
            stream.write(" ".join(map(str, row)) + "\n")
    parity_path = Path(str(prefix) + ".parity")
    parity_path.write_text(" ".join(map(str, parity)) + "\n")
    return {"order": n, "odd_elements": sum(parity),
            "multiplication_and_automorphism_sha256": hashlib.sha256(prefix.read_bytes()).hexdigest()}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("prefix", type=Path, nargs="?", default=Path("results/PGL11.cayley"))
    args = parser.parse_args()
    print(build(args.prefix))


if __name__ == "__main__":
    main()
