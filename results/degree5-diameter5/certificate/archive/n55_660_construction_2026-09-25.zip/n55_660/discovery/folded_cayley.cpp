#include <bits/stdc++.h>
using namespace std;
int n,K,D,na; vector<int> parity; int hfold;vector<int>mp,inv,unitid;vector<vector<int>>aut;struct U{int x,y,w;};vector<U>units;vector<int>iv,pairs;
vector<int>chosen,sg;vector<int>adjcols;bool found=false;double secs=300;chrono::steady_clock::time_point start;long long trials=0;int best=0;string tag;
bool stop(){return found||chrono::duration<double>(chrono::steady_clock::now()-start).count()>secs;}
int check(){
 trials++;int q[4000],seen[4000]={},ds[4000];q[0]=0;seen[0]=1;ds[0]=0;int l=0,r=1;
 while(l<r){int u=q[l++];if(ds[u]==D)continue;for(int s:sg){int v=adjcols[s*n+u];if(!seen[v]){seen[v]=1;ds[v]=ds[u]+1;q[r++]=v;}}}
 int odd=0;for(int v=0;v<n;v++)if(parity[v]&&seen[v])odd++;r=odd;if(r>best){best=r;cerr<<"BEST "<<best<<"/"<<n<<" trials="<<trials<<" gens=";for(int s:sg)cerr<<s<<",";cerr<<endl;}
 return r;
}
void save(){
 found=true;int nn=n/2;vector<int>cl(n,-1),reps;
 for(int x=0;x<n;x++)if(!parity[x]){int id=reps.size();cl[x]=cl[mp[hfold*n+x]]=id;reps.push_back(x);}
 assert((int)reps.size()==nn);set<pair<int,int>>es;
 for(int i=0;i<nn;i++)for(int s:sg){int j=cl[mp[reps[i]*n+s]];if(i!=j)es.emplace(min(i,j),max(i,j));}
 string fn="results/FOLDED_"+to_string(K)+"_"+to_string(D)+"_"+to_string(nn);
 ofstream o(fn+".edges");o<<nn<<"\n";for(auto [u,v]:es)o<<u<<" "<<v<<"\n";
 ofstream z(fn+".json");z<<"{\"group_data\":\""<<tag<<"\",\"fold_involution\":"<<hfold<<",\"generators\":[";for(int j=0;j<(int)sg.size();j++)z<<(j?",":"")<<sg[j];z<<"]}";cerr<<"SUCCESS "<<fn<<endl;
}
void add(int id){chosen.push_back(id);auto u=units[id];sg.push_back(u.x);if(u.w==2)sg.push_back(u.y);}
void pop(){auto u=units[chosen.back()];chosen.pop_back();sg.pop_back();if(u.w==2)sg.pop_back();}
void complete(int nr,int np,int lo){
 if((trials&16383)==0&&stop())return;
 if(!nr&&!np){if(check()==n/2)save();return;}
 auto &v=nr?iv:pairs;for(int j=lo;j<(int)v.size();j++){
  int id=v[j];if(find(chosen.begin(),chosen.end(),id)!=chosen.end())continue;
  add(id);if(nr)complete(nr-1,np,nr==1?0:j+1);else complete(0,np-1,j+1);pop();if(found)return;
 }
}
int main(int ac,char**av){
 tag=av[1];K=stoi(av[2]);D=stoi(av[3]);if(ac>4)secs=stod(av[4]);ifstream f(tag);f>>n>>na;if(n>3999)return 2;
 mp.resize(n*n);for(int&x:mp)f>>x;inv.resize(n);for(int&x:inv)f>>x;aut.assign(na,vector<int>(n));for(auto&v:aut)for(int&x:v)f>>x;
 parity.resize(n);ifstream pf(tag+".parity");for(int&x:parity)pf>>x;hfold=-1;for(int x=1;x<n;x++)if(parity[x]&&inv[x]==x){hfold=x;break;}if(hfold<0)return 3;unitid.assign(n,-1);for(int x=1;x<n;x++)if(parity[x]&&x<=inv[x]){int id=units.size();units.push_back({x,inv[x],x==inv[x]?1:2});unitid[x]=unitid[inv[x]]=id;(x==inv[x]?iv:pairs).push_back(id);}
 adjcols.resize(n*n);for(int i=0;i<n;i++)for(int j=0;j<n;j++)adjcols[j*n+i]=mp[i*n+j];
 cerr<<"GROUP "<<n<<" aut="<<na<<" involutions="<<iv.size()<<" pairs="<<pairs.size()<<endl;
 start=chrono::steady_clock::now();
 for(int ni=K%2;ni<=K;ni+=2){int np=(K-ni)/2;cerr<<"PATTERN involutions="<<ni<<" pairs="<<np<<endl;
  vector<int>firsts;set<int>seen;auto &all=ni?iv:pairs;
  for(int a:all){if(seen.count(a))continue;firsts.push_back(a);for(auto&h:aut)seen.insert(unitid[h[units[a].x]]);}
  for(int a:firsts){
   add(a);int nr=ni-(units[a].w==1),rp=np-(units[a].w==2);
   if(!nr&&!rp){if(check()==n/2)save();pop();continue;}
   vector<int>st;for(int h=0;h<na;h++)if(unitid[aut[h][units[a].x]]==a)st.push_back(h);
   auto&seconds=nr?iv:pairs;set<int>se;se.insert(a);
   for(int b:seconds){if(se.count(b))continue;for(int h:st)se.insert(unitid[aut[h][units[b].x]]);
    add(b);complete(nr-(units[b].w==1),rp-(units[b].w==2),0);pop();if(stop())break;
   }pop();if(stop())break;
  }if(stop())break;
 }
 cerr<<"DONE trials="<<trials<<" best="<<best<<" found="<<found<<" seconds="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
}
