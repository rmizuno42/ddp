#!/usr/bin/env python3
"""Verify the conjugacy from original discovery labels to the explicit matrices."""
from __future__ import annotations
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from construct import I, H, S, T, SQUARES, mul, inv, det, projective_group, edge_text
import hashlib


def verify() -> dict:
    generators = [(1, 1, 0, 1), T, (1, 0, 0, 6)]
    group = [I]
    lookup = {I: 0}
    position = 0
    while position < len(group):
        for s in generators:
            y = mul(group[position], s)
            if y not in lookup:
                lookup[y] = len(group)
                group.append(y)
        position += 1
    assert len(group) == 1320
    ids = [8, 335, 1044, 486, 987]
    old_s = [group[i] for i in ids]
    assert old_s == [(0, 1, 9, 0), (1, 9, 0, 10), (1, 0, 4, 10),
                     (1, 5, 1, 2), (1, 3, 5, 6)]
    old_h = group[8]
    c = (1, 4, 6, 9)
    ci = inv(c)
    conjugate = lambda x: mul(mul(c, x), ci)
    assert conjugate(old_h) == H and {conjugate(s) for s in old_s} == set(S)
    old_vertices = [x for x in group if det(x) in SQUARES]
    old_index = {x: i for i, x in enumerate(old_vertices)}
    new_vertices = [x for x in projective_group() if det(x) in SQUARES]
    new_index = {x: i for i, x in enumerate(new_vertices)}
    relabeling = [new_index[conjugate(x)] for x in old_vertices]
    assert len(set(relabeling)) == 660
    old_edges = set()
    for u, x in enumerate(old_vertices):
        for s in old_s:
            v = old_index[mul(mul(old_h, x), s)]
            if u != v:
                old_edges.add(tuple(sorted((u, v))))
    old_text = edge_text(660, old_edges)
    mapped = {tuple(sorted((relabeling[u], relabeling[v]))) for u, v in old_edges}
    mapped_text = edge_text(660, mapped)
    assert mapped_text == (ROOT / "graphs" / "n55_660_algebraic.edges").read_text()
    return {
        "valid": True,
        "original_generator_ids": ids,
        "original_generator_matrices": old_s,
        "conjugator": c,
        "conjugation_rule": "x -> C*x*C^{-1}",
        "original_graph_sha256": hashlib.sha256(old_text.encode()).hexdigest(),
        "canonical_graph_sha256": hashlib.sha256(mapped_text.encode()).hexdigest(),
        "exact_relabeling_verified": True,
    }


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2))
