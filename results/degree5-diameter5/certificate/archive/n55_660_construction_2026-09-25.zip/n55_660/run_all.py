#!/usr/bin/env python3
"""Reconstruct and verify all certificates; Python 3.10+, standard library only."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import tempfile
from construct import construct
from verify import verify as verify_graph
from verify_factorization import verify as verify_permutations

ROOT = Path(__file__).resolve().parent


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def main() -> None:
    # First freeze the exact files under test, then independently regenerate them.
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        path = ROOT / name
        require(path.is_file(), f"Missing file: {name}")
        require(hashlib.sha256(path.read_bytes()).hexdigest() == digest, f"Hash mismatch: {name}")
    print("PASS: SHA-256 manifest.")
    with tempfile.TemporaryDirectory(prefix="n55_660_") as directory:
        temp = Path(directory)
        construct(temp)
        for path in sorted(p for p in temp.rglob("*") if p.is_file()):
            relative = path.relative_to(temp)
            require(path.read_bytes() == (ROOT / relative).read_bytes(),
                    f"Reconstruction mismatch: {relative}")
    print("PASS: deterministic matrix reconstruction matches all frozen generated files.")
    result = verify_permutations(ROOT)
    require(result == json.loads((ROOT / "reports" / "permutation_verification.json").read_text()),
            "Permutation-verification report mismatch.")
    print("PASS: independent 12-point permutation verification of S^5 and all 660 words.")
    print("PASS: both edge sets independently reconstructed as permutations.")
    for name, report_name in [("algebraic", "algebraic_graph"), ("regular", "regular_graph")]:
        result = verify_graph(ROOT / "graphs" / f"n55_660_{name}.edges", 5, 5)
        frozen = json.loads((ROOT / "reports" / f"{report_name}.json").read_text())
        # Normalize JSON dictionary keys to strings for the comparison.
        require(json.loads(json.dumps(result)) == frozen, f"Graph-verification report mismatch: {name}")
        require(result["valid"] and result["vertices"] == 660 and result["diameter"] == 5,
                f"Invalid graph: {name}")
        if name == "regular":
            require(result["degree_histogram"] == {5: 660}, "The completed graph is not 5-regular.")
        print(f"PASS: {name} graph: 660 vertices, {result['edges']} edges, maximum degree 5, diameter 5.")
    print("VERIFIED: N(5,5) >= 660; a simple 5-regular certificate is included.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError, AssertionError, KeyError) as error:
        raise SystemExit(f"FAIL: {error}") from error
