#!/usr/bin/env python3
"""Independent strict edge-list parser and all-pairs BFS verifier.

Format: first line n; subsequent lines u v, with 0 <= u < v < n.
Only Python standard-library modules are required.
"""
from __future__ import annotations
import argparse
from collections import Counter, deque
import hashlib
import json
from pathlib import Path

def verify(path: Path, degree_bound: int, diameter_bound: int) -> dict:
    lines = path.read_text().splitlines()
    if not lines or len(lines[0].split()) != 1:
        raise ValueError('Expected the number of vertices on the first line.')
    n = int(lines[0])
    if n <= 0:
        raise ValueError('The graph order must be positive.')
    adj = [set() for _ in range(n)]
    edges: set[tuple[int, int]] = set()
    for line_no, line in enumerate(lines[1:], 2):
        if not line.strip():
            continue
        fields = line.split()
        if len(fields) != 2:
            raise ValueError(f'Line {line_no}: expected two vertex labels.')
        u, v = map(int, fields)
        if not 0 <= u < v < n:
            raise ValueError(f'Line {line_no}: invalid or noncanonical edge.')
        if (u, v) in edges:
            raise ValueError(f'Line {line_no}: duplicate edge.')
        edges.add((u, v))
        adj[u].add(v)
        adj[v].add(u)
    degrees = Counter(map(len, adj))
    eccentricities: Counter[int] = Counter()
    distances: Counter[int] = Counter()
    connected = True
    violations = 0
    examples: list[list[int]] = []
    for source in range(n):
        dist = [-1] * n
        dist[source] = 0
        queue = deque([source])
        while queue:
            v = queue.popleft()
            for w in adj[v]:
                if dist[w] == -1:
                    dist[w] = dist[v] + 1
                    queue.append(w)
        if -1 in dist:
            connected = False
        eccentricities[max(dist) if -1 not in dist else -1] += 1
        for target in range(source + 1, n):
            d = dist[target]
            distances[d] += 1
            if d < 0 or d > diameter_bound:
                violations += 1
                if len(examples) < 20:
                    examples.append([source, target, d])
    diameter = max(eccentricities) if connected else None
    canonical = str(n) + '\n' + ''.join(f'{u} {v}\n' for u, v in sorted(edges))
    return {
        'vertices': n, 'edges': len(edges), 'simple': True,
        'connected': connected, 'degree_histogram': dict(sorted(degrees.items())),
        'maximum_degree': max(degrees), 'diameter': diameter,
        'eccentricity_histogram': dict(sorted(eccentricities.items())),
        'unordered_distance_histogram': dict(sorted(distances.items())),
        'diameter_bound_violations': violations, 'violation_examples': examples,
        'canonical_sha256': hashlib.sha256(canonical.encode()).hexdigest(),
        'valid': connected and max(degrees) <= degree_bound and violations == 0,
        'bounds_checked': {'degree': degree_bound, 'diameter': diameter_bound},
    }

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('graph', type=Path)
    parser.add_argument('--degree', type=int, required=True)
    parser.add_argument('--diameter', type=int, required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        result = verify(args.graph, args.degree, args.diameter)
    except (OSError, ValueError) as error:
        parser.exit(2, f'Verification error: {error}\n')
    text = json.dumps(result, indent=2, ensure_ascii=False)
    print(text)
    if args.output:
        args.output.write_text(text + '\n')
    raise SystemExit(0 if result['valid'] else 1)

if __name__ == '__main__':
    main()
