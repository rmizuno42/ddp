#!/usr/bin/env python3
"""Independent exact checker using permutations of the projective line.

Does NOT import construct.py or use its projective-matrix multiplication.
Checks every supplied five-letter factorization, computes the product-set
cardinalities independently, and reconstructs both graphs as permutations.
Python standard library only; use Python 3.10 or later.
"""
from __future__ import annotations
import argparse
import csv
import itertools
import json
from pathlib import Path

P = 11
Matrix = tuple[int, int, int, int]
Permutation = tuple[int, ...]
MATRICES: dict[str, Matrix] = {
    "h": (1, 0, 0, 10), "a": (1, 1, 4, 10), "b": (1, 5, 3, 10),
    "r": (0, 1, 3, 8), "R": (1, 4, 1, 0),
}
T: Matrix = (0, 1, 10, 0)
IDENTITY = tuple(range(12))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def compose(p: Permutation, q: Permutation) -> Permutation:
    """The permutation p after q; matches the left action of matrix p*q."""
    return tuple(p[q[i]] for i in range(12))


def mobius(m: Matrix) -> Permutation:
    a, b, c, d = m
    result = []
    for z in range(12):
        numerator, denominator = (a, c) if z == 11 else (a * z + b, c * z + d)
        numerator %= 11
        denominator %= 11
        require(numerator != 0 or denominator != 0, "Singular Mobius matrix.")
        result.append(11 if denominator == 0 else numerator * pow(denominator, 9, 11) % 11)
    require(set(result) == set(range(12)), "Mobius action is not a permutation.")
    return tuple(result)


def enumerate_cosets() -> tuple[list[Matrix], list[Matrix]]:
    # Independent enumeration: all 11^4 matrices, not the normalized-form formula.
    classes: dict[Matrix, int] = {}
    for m in itertools.product(range(11), repeat=4):
        a, b, c, d = m
        determinant = (a * d - b * c) % 11
        if determinant == 0:
            continue
        first = next(z for z in m if z)
        normalized = tuple(z * pow(first, 9, 11) % 11 for z in m)
        sign = pow(determinant, 5, 11)  # Euler's criterion: +1 or -1.
        require(sign in (1, 10), "Unexpected determinant square class.")
        if normalized in classes:
            require(classes[normalized] == sign, "Square class is not projectively invariant.")
        classes[normalized] = sign
    return sorted(m for m, sign in classes.items() if sign == 1), \
        sorted(m for m, sign in classes.items() if sign == 10)


def read_edges(path: Path) -> set[tuple[int, int]]:
    lines = path.read_text().splitlines()
    require(lines[0] == "660", f"Wrong graph order in {path.name}.")
    edges: set[tuple[int, int]] = set()
    for line in lines[1:]:
        fields = line.split()
        require(len(fields) == 2, "Malformed graph edge.")
        u, v = map(int, fields)
        require(0 <= u < v < 660, "Noncanonical graph edge.")
        require((u, v) not in edges, "Duplicate graph edge.")
        edges.add((u, v))
    return edges


def verify(root: Path) -> dict:
    positive, negative = enumerate_cosets()
    require(len(positive) == len(negative) == 660, "Wrong group orders.")
    positive_perms = [mobius(m) for m in positive]
    negative_perms = {mobius(m) for m in negative}
    require(len(set(positive_perms)) == 660 and len(negative_perms) == 660,
            "The permutation action is not faithful on these classes.")
    require(set(positive_perms).isdisjoint(negative_perms), "Cosets overlap.")
    generators = {s: mobius(m) for s, m in MATRICES.items()}
    h, t = generators["h"], mobius(T)
    require(compose(h, h) == IDENTITY, "h is not an involution.")
    require(t != IDENTITY and compose(t, t) == IDENTITY, "t is not an involution.")
    require(compose(t, h) == compose(h, t), "t and h do not commute.")
    require(all(g in negative_perms for g in generators.values()), "A generator has square determinant.")
    require(all(any(compose(s, z) == IDENTITY for z in generators.values())
                for s in generators.values()), "S is not inverse closed.")
    involutions = [symbol for symbol, s in generators.items() if compose(s, s) == IDENTITY]
    require(involutions == ["h", "a", "b"], "Unexpected involutions in S.")
    require(all(compose(generators[u], generators[v]) != compose(generators[v], generators[u])
                for u, v in itertools.combinations(involutions, 2)),
            "Two distinct involutions in S commute.")
    orders = {}
    for name, s in generators.items():
        current = IDENTITY
        for k in range(1, 1321):
            current = compose(current, s)
            if current == IDENTITY:
                orders[name] = k
                break
        require(name in orders, "Unable to find a generator order.")

    # Independent full fixed-length product-set calculation in degree 12 permutations.
    products = {IDENTITY}
    sizes = [1]
    for _ in range(5):
        products = {compose(x, s) for x in products for s in generators.values()}
        sizes.append(len(products))
    require(sizes == [1, 5, 21, 85, 341, 660], "Incorrect product-set sizes.")
    require(products == negative_perms, "S^5 is not the entire negative coset.")

    seen: set[Matrix] = set()
    with (root / "word_certificate.tsv").open(newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        require(reader.fieldnames == ["a", "b", "c", "d", "word"], "Incorrect certificate columns.")
        for row in reader:
            m = tuple(int(row[z]) for z in "abcd")
            word = row["word"]
            require(m not in seen, "Repeated target matrix in word certificate.")
            require(m in set(negative), "Certificate target is not a canonical negative matrix.")
            require(len(word) == 5 and all(s in generators for s in word), "Invalid five-letter word.")
            value = IDENTITY
            for symbol in word:
                value = compose(value, generators[symbol])
            require(value == mobius(m), "Word does not evaluate to its declared matrix.")
            seen.add(m)
    require(seen == set(negative), "Word certificate does not cover every negative matrix.")

    with (root / "vertices.tsv").open(newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        require(reader.fieldnames == ["id", "a", "b", "c", "d"], "Incorrect vertex columns.")
        rows = list(reader)
    require(len(rows) == 660, "Wrong vertex label count.")
    for expected_id, row in enumerate(rows):
        require(int(row["id"]) == expected_id, "Vertex IDs are not consecutive.")
        require(tuple(int(row[z]) for z in "abcd") == positive[expected_id], "Wrong vertex matrix.")

    # Independent adjacency reconstruction, using only permutations.
    index = {permutation: i for i, permutation in enumerate(positive_perms)}
    edges: set[tuple[int, int]] = set()
    deficient: set[int] = set()
    for u, x in enumerate(positive_perms):
        for s in generators.values():
            y = compose(h, compose(x, s))
            require(y in index, "An edge exits the positive coset.")
            v = index[y]
            if u == v:
                deficient.add(u)
            else:
                edges.add(tuple(sorted((u, v))))
    require(edges == read_edges(root / "graphs" / "n55_660_algebraic.edges"),
            "Algebraic graph does not match the independent permutation reconstruction.")
    matching: set[tuple[int, int]] = set()
    for u in deficient:
        v = index[compose(t, positive_perms[u])]
        require(v in deficient and u != v, "Completion does not preserve the deficient vertex set.")
        edge = tuple(sorted((u, v)))
        require(edge not in edges, "A completion edge already exists.")
        matching.add(edge)
    require(len(matching) == 15, "The completion does not have 15 edges.")
    require(matching == read_edges(root / "graphs" / "regular_completion.edges"), "Wrong completion file.")
    require(edges | matching == read_edges(root / "graphs" / "n55_660_regular.edges"),
            "Regular graph does not match the independent permutation reconstruction.")
    return {
        "valid": True, "representation": "Permutations of P^1(F_11), 12 points",
        "imports_construction_module": False,
        "coset_sizes": [len(positive), len(negative)], "generator_orders": orders,
        "exact_product_set_sizes_k_0_to_5": sizes,
        "five_letter_word_certificates_checked": len(seen),
        "factorization_identity_verified": True,
        "algebraic_graph_independently_reconstructed": True,
        "regular_graph_independently_reconstructed": True,
        "noncommuting_involutions_in_S": involutions,
        "completion_matching_size": len(matching),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        report = verify(args.root)
    except (OSError, ValueError, KeyError, IndexError) as error:
        parser.exit(1, f"Verification failed: {error}\n")
    text = json.dumps(report, indent=2)
    print(text)
    if args.output:
        args.output.write_text(text + "\n")


if __name__ == "__main__":
    main()
